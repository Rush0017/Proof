import { SignIn } from '@clerk/nextjs';
import Link from 'next/link';
import { Zap } from 'lucide-react';

export default function SignInPage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center bg-background px-4">
      <Link href="/" className="flex items-center gap-2 mb-8">
        <div className="w-10 h-10 rounded-lg bg-bitcoin flex items-center justify-center">
          <Zap className="w-6 h-6 text-white" />
        </div>
        <span className="text-2xl font-bold">Proof</span>
      </Link>
      
      <SignIn 
        appearance={{
          elements: {
            rootBox: 'mx-auto',
            card: 'shadow-lg',
            headerTitle: 'text-xl font-bold',
            headerSubtitle: 'text-muted-foreground',
            socialButtonsBlockButton: 'border hover:bg-muted',
            formFieldInput: 'border focus:ring-2 focus:ring-bitcoin',
            formButtonPrimary: 'bg-bitcoin hover:bg-bitcoin-dark',
            footerActionLink: 'text-bitcoin hover:text-bitcoin-dark',
          },
        }}
        redirectUrl="/dashboard"
        signUpUrl="/sign-up"
      />
      
      <p className="mt-8 text-sm text-muted-foreground text-center max-w-md">
        By signing in, you agree to our{' '}
        <Link href="/terms" className="underline hover:text-foreground">
          Terms of Service
        </Link>{' '}
        and{' '}
        <Link href="/privacy" className="underline hover:text-foreground">
          Privacy Policy
        </Link>
        .
      </p>
    </div>
  );
}
