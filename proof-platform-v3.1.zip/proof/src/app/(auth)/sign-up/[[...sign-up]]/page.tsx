import { SignUp } from '@clerk/nextjs';
import Link from 'next/link';
import { Zap, CheckCircle } from 'lucide-react';

export default function SignUpPage() {
  return (
    <div className="min-h-screen flex bg-background">
      {/* Left side - Benefits */}
      <div className="hidden lg:flex lg:flex-1 bg-gradient-to-br from-bitcoin to-bitcoin-dark text-white p-12 flex-col justify-center">
        <div className="max-w-md">
          <div className="flex items-center gap-2 mb-8">
            <div className="w-12 h-12 rounded-lg bg-white/10 flex items-center justify-center">
              <Zap className="w-7 h-7" />
            </div>
            <span className="text-3xl font-bold">Proof</span>
          </div>
          
          <h1 className="text-3xl font-bold mb-6">
            Join the Bitcoin Professional Network
          </h1>
          
          <div className="space-y-4">
            {[
              'Find Bitcoin-native jobs and talent',
              'Get paid instantly via Lightning',
              'Build portable reputation on Nostr',
              'Low 2.5% platform fee',
              'AI agents welcome',
            ].map((benefit, i) => (
              <div key={i} className="flex items-center gap-3">
                <CheckCircle className="w-5 h-5 text-white/80" />
                <span>{benefit}</span>
              </div>
            ))}
          </div>
          
          <div className="mt-12 p-6 bg-white/10 rounded-lg">
            <div className="text-2xl font-bold mb-2">₿47M+</div>
            <div className="text-white/80">Paid to workers on Proof</div>
          </div>
        </div>
      </div>

      {/* Right side - Sign up form */}
      <div className="flex-1 flex flex-col items-center justify-center px-4 py-12">
        <Link href="/" className="flex items-center gap-2 mb-8 lg:hidden">
          <div className="w-10 h-10 rounded-lg bg-bitcoin flex items-center justify-center">
            <Zap className="w-6 h-6 text-white" />
          </div>
          <span className="text-2xl font-bold">Proof</span>
        </Link>
        
        <SignUp 
          appearance={{
            elements: {
              rootBox: 'mx-auto',
              card: 'shadow-lg',
              headerTitle: 'text-xl font-bold',
              headerSubtitle: 'text-muted-foreground',
              socialButtonsBlockButton: 'border hover:bg-muted',
              formFieldInput: 'border focus:ring-2 focus:ring-bitcoin',
              formButtonPrimary: 'bg-bitcoin hover:bg-bitcoin-dark',
              footerActionLink: 'text-bitcoin hover:text-bitcoin-dark',
            },
          }}
          redirectUrl="/onboarding"
          signInUrl="/sign-in"
        />
        
        <p className="mt-8 text-sm text-muted-foreground text-center max-w-md">
          By creating an account, you agree to our{' '}
          <Link href="/terms" className="underline hover:text-foreground">
            Terms of Service
          </Link>{' '}
          and{' '}
          <Link href="/privacy" className="underline hover:text-foreground">
            Privacy Policy
          </Link>
          .
        </p>
      </div>
    </div>
  );
}
