import { NextRequest, NextResponse } from 'next/server';
import { withL402 } from '@/lib/l402';
import { createServerClient } from '@/lib/supabase';

/**
 * L402 Protected Jobs Endpoint
 * 
 * Costs: 10 sats per request
 * No authentication required - payment IS authentication
 * 
 * Perfect for AI agents that want to browse jobs without creating an account.
 */
export const GET = withL402(async (request: NextRequest, context) => {
  const searchParams = request.nextUrl.searchParams;
  const supabase = createServerClient();

  // Parse query params
  const skills = searchParams.get('skills')?.split(',');
  const minBudget = searchParams.get('min_budget');
  const maxBudget = searchParams.get('max_budget');
  const search = searchParams.get('search');
  const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 50);

  // Build query - only open, agent-friendly jobs
  let query = supabase
    .from('jobs')
    .select(`
      id,
      title,
      description,
      budget_sats,
      payment_type,
      required_skills,
      preferred_skills,
      experience_level,
      location_requirement,
      allows_agents,
      escrow_funded,
      created_at,
      application_deadline,
      poster:users!jobs_poster_id_fkey(
        display_name,
        reputation_score,
        nip05_identifier
      )
    `)
    .eq('is_public', true)
    .eq('status', 'open')
    .eq('allows_agents', true) // Only agent-friendly jobs
    .order('created_at', { ascending: false })
    .limit(limit);

  // Apply filters
  if (skills && skills.length > 0) {
    query = query.overlaps('required_skills', skills);
  }

  if (minBudget) {
    query = query.gte('budget_sats', parseInt(minBudget));
  }

  if (maxBudget) {
    query = query.lte('budget_sats', parseInt(maxBudget));
  }

  if (search) {
    query = query.textSearch('title', search, { type: 'websearch' });
  }

  const { data: jobs, error } = await query;

  if (error) {
    console.error('Error fetching jobs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch jobs' },
      { status: 500 }
    );
  }

  // Log the payment for analytics
  if (context.paymentHash) {
    console.log(`L402 payment received: ${context.paymentHash} for /api/l402/jobs`);
  }

  return NextResponse.json({
    jobs,
    meta: {
      count: jobs.length,
      payment_hash: context.paymentHash,
    },
  });
});
