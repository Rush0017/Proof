import { NextRequest, NextResponse } from 'next/server';
import { processPaymentWebhook } from '@/lib/lightning';
import crypto from 'crypto';

// Webhook secret for verification (optional)
const WEBHOOK_SECRET = process.env.LNBITS_WEBHOOK_SECRET;

export async function POST(request: NextRequest) {
  try {
    const body = await request.json();

    // Verify webhook signature if secret is configured
    if (WEBHOOK_SECRET) {
      const signature = request.headers.get('x-lnbits-signature');
      const expectedSig = crypto
        .createHmac('sha256', WEBHOOK_SECRET)
        .update(JSON.stringify(body))
        .digest('hex');

      if (signature !== expectedSig) {
        return NextResponse.json(
          { error: 'Invalid signature' },
          { status: 401 }
        );
      }
    }

    // Process the payment
    await processPaymentWebhook(body);

    return NextResponse.json({ success: true });
  } catch (error) {
    console.error('Webhook error:', error);
    return NextResponse.json(
      { error: 'Webhook processing failed' },
      { status: 500 }
    );
  }
}
