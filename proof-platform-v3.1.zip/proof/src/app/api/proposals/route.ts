import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs';
import { createServerClient } from '@/lib/supabase';
import { z } from 'zod';

const createProposalSchema = z.object({
  job_id: z.string().uuid(),
  cover_letter: z.string().min(100).max(5000),
  proposed_rate_sats: z.number().min(1).optional(),
  estimated_hours: z.number().min(1).optional(),
  estimated_days: z.number().min(1).optional(),
});

// GET /api/proposals - List user's proposals
export async function GET(request: NextRequest) {
  const { userId } = auth();
  
  if (!userId) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const supabase = createServerClient();
  const searchParams = request.nextUrl.searchParams;
  const status = searchParams.get('status');

  // Get user
  const { data: user } = await supabase
    .from('users')
    .select('id')
    .eq('clerk_id', userId)
    .single();

  if (!user) {
    return NextResponse.json(
      { error: 'User not found' },
      { status: 404 }
    );
  }

  // Build query
  let query = supabase
    .from('proposals')
    .select(`
      *,
      job:jobs(
        id,
        title,
        budget_sats,
        status,
        poster:users!jobs_poster_id_fkey(
          display_name,
          avatar_url
        )
      )
    `)
    .eq('proposer_id', user.id)
    .order('created_at', { ascending: false });

  if (status) {
    query = query.eq('status', status);
  }

  const { data: proposals, error } = await query;

  if (error) {
    console.error('Error fetching proposals:', error);
    return NextResponse.json(
      { error: 'Failed to fetch proposals' },
      { status: 500 }
    );
  }

  return NextResponse.json({ proposals });
}

// POST /api/proposals - Submit a proposal
export async function POST(request: NextRequest) {
  const { userId } = auth();
  
  if (!userId) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const supabase = createServerClient();

  // Get user
  const { data: user } = await supabase
    .from('users')
    .select('id, is_agent')
    .eq('clerk_id', userId)
    .single();

  if (!user) {
    return NextResponse.json(
      { error: 'User not found' },
      { status: 404 }
    );
  }

  // Parse request body
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON' },
      { status: 400 }
    );
  }

  const validationResult = createProposalSchema.safeParse(body);
  if (!validationResult.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: validationResult.error.issues },
      { status: 400 }
    );
  }

  const proposalData = validationResult.data;

  // Check if job exists and is open
  const { data: job, error: jobError } = await supabase
    .from('jobs')
    .select('id, status, allows_agents, poster_id')
    .eq('id', proposalData.job_id)
    .single();

  if (jobError || !job) {
    return NextResponse.json(
      { error: 'Job not found' },
      { status: 404 }
    );
  }

  if (job.status !== 'open') {
    return NextResponse.json(
      { error: 'Job is not accepting proposals' },
      { status: 400 }
    );
  }

  // Check if user is the poster
  if (job.poster_id === user.id) {
    return NextResponse.json(
      { error: 'Cannot submit proposal to your own job' },
      { status: 400 }
    );
  }

  // Check if agents are allowed
  if (user.is_agent && !job.allows_agents) {
    return NextResponse.json(
      { error: 'This job does not accept agent applications' },
      { status: 400 }
    );
  }

  // Check for existing proposal
  const { data: existingProposal } = await supabase
    .from('proposals')
    .select('id')
    .eq('job_id', proposalData.job_id)
    .eq('proposer_id', user.id)
    .single();

  if (existingProposal) {
    return NextResponse.json(
      { error: 'You have already submitted a proposal for this job' },
      { status: 400 }
    );
  }

  // Create proposal
  const { data: proposal, error: proposalError } = await supabase
    .from('proposals')
    .insert({
      job_id: proposalData.job_id,
      proposer_id: user.id,
      cover_letter: proposalData.cover_letter,
      proposed_rate_sats: proposalData.proposed_rate_sats,
      estimated_hours: proposalData.estimated_hours,
      estimated_days: proposalData.estimated_days,
      status: 'pending',
    })
    .select()
    .single();

  if (proposalError) {
    console.error('Error creating proposal:', proposalError);
    return NextResponse.json(
      { error: 'Failed to create proposal' },
      { status: 500 }
    );
  }

  // Create notification for job poster
  await supabase.from('notifications').insert({
    user_id: job.poster_id,
    type: 'new_proposal',
    title: 'New Proposal Received',
    body: `Someone submitted a proposal for your job`,
    job_id: job.id,
    proposal_id: proposal.id,
    action_url: `/jobs/${job.id}/proposals`,
  });

  return NextResponse.json({ proposal }, { status: 201 });
}
