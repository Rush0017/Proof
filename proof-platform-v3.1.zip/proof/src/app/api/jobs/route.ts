import { NextRequest, NextResponse } from 'next/server';
import { auth } from '@clerk/nextjs';
import { createServerClient } from '@/lib/supabase';
import { z } from 'zod';

// Validation schema
const createJobSchema = z.object({
  title: z.string().min(5).max(200),
  description: z.string().min(50).max(10000),
  budget_sats: z.number().min(1000),
  payment_type: z.enum(['fixed', 'hourly', 'milestone']),
  required_skills: z.array(z.string()).min(1).max(10),
  preferred_skills: z.array(z.string()).max(10).optional(),
  experience_level: z.enum(['entry', 'intermediate', 'senior', 'expert']).optional(),
  location_requirement: z.string().default('remote'),
  allows_agents: z.boolean().default(true),
  application_deadline: z.string().optional(),
  completion_deadline: z.string().optional(),
  milestones: z.array(z.object({
    title: z.string(),
    description: z.string().optional(),
    amount_sats: z.number().min(1),
  })).optional(),
});

// GET /api/jobs - List jobs with filters
export async function GET(request: NextRequest) {
  const searchParams = request.nextUrl.searchParams;
  const supabase = createServerClient();

  // Parse query params
  const status = searchParams.get('status') || 'open';
  const skills = searchParams.get('skills')?.split(',');
  const minBudget = searchParams.get('min_budget');
  const maxBudget = searchParams.get('max_budget');
  const allowsAgents = searchParams.get('allows_agents');
  const search = searchParams.get('search');
  const page = parseInt(searchParams.get('page') || '1');
  const limit = Math.min(parseInt(searchParams.get('limit') || '20'), 50);
  const offset = (page - 1) * limit;

  // Build query
  let query = supabase
    .from('jobs')
    .select(`
      *,
      poster:users!jobs_poster_id_fkey(
        id,
        display_name,
        avatar_url,
        reputation_score,
        is_agent,
        nip05_verified
      ),
      proposals:proposals(count)
    `, { count: 'exact' })
    .eq('is_public', true)
    .eq('status', status)
    .order('created_at', { ascending: false })
    .range(offset, offset + limit - 1);

  // Apply filters
  if (skills && skills.length > 0) {
    query = query.overlaps('required_skills', skills);
  }

  if (minBudget) {
    query = query.gte('budget_sats', parseInt(minBudget));
  }

  if (maxBudget) {
    query = query.lte('budget_sats', parseInt(maxBudget));
  }

  if (allowsAgents === 'true') {
    query = query.eq('allows_agents', true);
  }

  if (search) {
    query = query.textSearch('title', search, { type: 'websearch' });
  }

  const { data: jobs, error, count } = await query;

  if (error) {
    console.error('Error fetching jobs:', error);
    return NextResponse.json(
      { error: 'Failed to fetch jobs' },
      { status: 500 }
    );
  }

  return NextResponse.json({
    jobs,
    pagination: {
      page,
      limit,
      total: count || 0,
      total_pages: Math.ceil((count || 0) / limit),
    },
  });
}

// POST /api/jobs - Create a new job
export async function POST(request: NextRequest) {
  const { userId } = auth();
  
  if (!userId) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const supabase = createServerClient();

  // Get user from database
  const { data: user, error: userError } = await supabase
    .from('users')
    .select('id')
    .eq('clerk_id', userId)
    .single();

  if (userError || !user) {
    return NextResponse.json(
      { error: 'User not found' },
      { status: 404 }
    );
  }

  // Parse and validate request body
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON' },
      { status: 400 }
    );
  }

  const validationResult = createJobSchema.safeParse(body);
  if (!validationResult.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: validationResult.error.issues },
      { status: 400 }
    );
  }

  const jobData = validationResult.data;

  // Calculate escrow amount (budget + 2.5% platform fee)
  const platformFee = Math.ceil(jobData.budget_sats * 0.025);
  const escrowAmount = jobData.budget_sats + platformFee;

  // Create job
  const { data: job, error: jobError } = await supabase
    .from('jobs')
    .insert({
      poster_id: user.id,
      title: jobData.title,
      description: jobData.description,
      budget_sats: jobData.budget_sats,
      payment_type: jobData.payment_type,
      required_skills: jobData.required_skills,
      preferred_skills: jobData.preferred_skills || [],
      experience_level: jobData.experience_level,
      location_requirement: jobData.location_requirement,
      allows_agents: jobData.allows_agents,
      application_deadline: jobData.application_deadline,
      completion_deadline: jobData.completion_deadline,
      status: 'draft',
      escrow_amount_sats: escrowAmount,
    })
    .select()
    .single();

  if (jobError) {
    console.error('Error creating job:', jobError);
    return NextResponse.json(
      { error: 'Failed to create job' },
      { status: 500 }
    );
  }

  // Create milestones if provided
  if (jobData.milestones && jobData.milestones.length > 0) {
    const milestones = jobData.milestones.map((m, index) => ({
      job_id: job.id,
      title: m.title,
      description: m.description,
      amount_sats: m.amount_sats,
      order_index: index,
    }));

    const { error: milestoneError } = await supabase
      .from('milestones')
      .insert(milestones);

    if (milestoneError) {
      console.error('Error creating milestones:', milestoneError);
      // Don't fail the job creation, just log the error
    }
  }

  return NextResponse.json({ job }, { status: 201 });
}
