import { NextRequest, NextResponse } from 'next/server';
import { auth, currentUser } from '@clerk/nextjs';
import { createServerClient } from '@/lib/supabase';
import { z } from 'zod';

const updateProfileSchema = z.object({
  display_name: z.string().min(2).max(100).optional(),
  username: z.string().min(3).max(30).regex(/^[a-z0-9_]+$/).optional(),
  bio: z.string().max(500).optional(),
  location: z.string().max(100).optional(),
  website: z.string().url().optional().or(z.literal('')),
  timezone: z.string().optional(),
  lightning_address: z.string().email().optional().or(z.literal('')),
  allows_agent_applications: z.boolean().optional(),
  public_profile: z.boolean().optional(),
});

// GET /api/users/me - Get current user profile
export async function GET() {
  const { userId } = auth();
  
  if (!userId) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const supabase = createServerClient();

  // Get user with skills
  const { data: user, error } = await supabase
    .from('users')
    .select(`
      *,
      skills:user_skills(*)
    `)
    .eq('clerk_id', userId)
    .single();

  if (error || !user) {
    // User doesn't exist in our DB yet - create them
    const clerkUser = await currentUser();
    
    if (!clerkUser) {
      return NextResponse.json(
        { error: 'User not found' },
        { status: 404 }
      );
    }

    const { data: newUser, error: createError } = await supabase
      .from('users')
      .insert({
        clerk_id: userId,
        display_name: clerkUser.firstName 
          ? `${clerkUser.firstName} ${clerkUser.lastName || ''}`.trim()
          : clerkUser.username || 'Anonymous',
        email: clerkUser.emailAddresses[0]?.emailAddress,
        email_verified: clerkUser.emailAddresses[0]?.verification?.status === 'verified',
        avatar_url: clerkUser.imageUrl,
      })
      .select()
      .single();

    if (createError) {
      console.error('Error creating user:', createError);
      return NextResponse.json(
        { error: 'Failed to create user' },
        { status: 500 }
      );
    }

    return NextResponse.json({ user: newUser });
  }

  return NextResponse.json({ user });
}

// PUT /api/users/me - Update current user profile
export async function PUT(request: NextRequest) {
  const { userId } = auth();
  
  if (!userId) {
    return NextResponse.json(
      { error: 'Unauthorized' },
      { status: 401 }
    );
  }

  const supabase = createServerClient();

  // Parse and validate request body
  let body;
  try {
    body = await request.json();
  } catch {
    return NextResponse.json(
      { error: 'Invalid JSON' },
      { status: 400 }
    );
  }

  const validationResult = updateProfileSchema.safeParse(body);
  if (!validationResult.success) {
    return NextResponse.json(
      { error: 'Validation failed', details: validationResult.error.issues },
      { status: 400 }
    );
  }

  const updates = validationResult.data;

  // Check username uniqueness if being updated
  if (updates.username) {
    const { data: existing } = await supabase
      .from('users')
      .select('id')
      .eq('username', updates.username)
      .neq('clerk_id', userId)
      .single();

    if (existing) {
      return NextResponse.json(
        { error: 'Username already taken' },
        { status: 400 }
      );
    }
  }

  // Update user
  const { data: user, error } = await supabase
    .from('users')
    .update(updates)
    .eq('clerk_id', userId)
    .select()
    .single();

  if (error) {
    console.error('Error updating user:', error);
    return NextResponse.json(
      { error: 'Failed to update user' },
      { status: 500 }
    );
  }

  return NextResponse.json({ user });
}
