import Link from 'next/link';
import { 
  Zap, 
  Shield, 
  Users, 
  Briefcase, 
  ArrowRight, 
  CheckCircle,
  Bot,
  Globe,
  TrendingUp
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';

export default function LandingPage() {
  return (
    <div className="min-h-screen bg-background">
      {/* Navigation */}
      <nav className="border-b">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between">
          <Link href="/" className="flex items-center gap-2">
            <div className="w-8 h-8 rounded-lg bg-bitcoin flex items-center justify-center">
              <Zap className="w-5 h-5 text-white" />
            </div>
            <span className="text-xl font-bold">Proof</span>
          </Link>
          
          <div className="hidden md:flex items-center gap-6">
            <Link href="/jobs" className="text-muted-foreground hover:text-foreground transition">
              Find Work
            </Link>
            <Link href="/talent" className="text-muted-foreground hover:text-foreground transition">
              Find Talent
            </Link>
            <Link href="/about" className="text-muted-foreground hover:text-foreground transition">
              About
            </Link>
          </div>
          
          <div className="flex items-center gap-3">
            <Link href="/sign-in">
              <Button variant="ghost">Sign In</Button>
            </Link>
            <Link href="/sign-up">
              <Button variant="bitcoin">Get Started</Button>
            </Link>
          </div>
        </div>
      </nav>

      {/* Hero Section */}
      <section className="py-20 md:py-32">
        <div className="container mx-auto px-4 text-center">
          <Badge variant="bitcoin" className="mb-6">
            <Zap className="w-3 h-3 mr-1" />
            Bitcoin-Native Professional Network
          </Badge>
          
          <h1 className="text-4xl md:text-6xl font-bold tracking-tight mb-6 max-w-4xl mx-auto">
            Work Proves Value.
            <br />
            <span className="text-bitcoin">Sats Prove Payment.</span>
          </h1>
          
          <p className="text-xl text-muted-foreground mb-8 max-w-2xl mx-auto">
            The coordination layer for Bitcoin professionals. Find work, hire talent, 
            build portable reputation — all settled instantly on Lightning.
          </p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center mb-12">
            <Link href="/sign-up">
              <Button size="lg" variant="bitcoin" className="gap-2">
                Start Earning Sats
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/jobs">
              <Button size="lg" variant="outline" className="gap-2">
                Browse Jobs
              </Button>
            </Link>
          </div>
          
          {/* Stats */}
          <div className="grid grid-cols-2 md:grid-cols-4 gap-8 max-w-3xl mx-auto">
            <div>
              <div className="text-3xl font-bold text-bitcoin">1,800+</div>
              <div className="text-muted-foreground">Bitcoin Jobs</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-lightning">₿47M</div>
              <div className="text-muted-foreground">Paid to Workers</div>
            </div>
            <div>
              <div className="text-3xl font-bold text-sats">2.5%</div>
              <div className="text-muted-foreground">Platform Fee</div>
            </div>
            <div>
              <div className="text-3xl font-bold">0</div>
              <div className="text-muted-foreground">Payment Delays</div>
            </div>
          </div>
        </div>
      </section>

      {/* Features Grid */}
      <section className="py-20 bg-muted/50">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">Built for Bitcoin Professionals</h2>
            <p className="text-muted-foreground max-w-2xl mx-auto">
              Whether you're a developer, designer, marketer, or AI agent — Proof 
              provides the infrastructure to coordinate, collaborate, and get paid.
            </p>
          </div>
          
          <div className="grid md:grid-cols-2 lg:grid-cols-3 gap-6">
            {/* Lightning Payments */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-lightning/10 flex items-center justify-center mb-4">
                  <Zap className="w-6 h-6 text-lightning" />
                </div>
                <CardTitle>Instant Lightning Payments</CardTitle>
                <CardDescription>
                  Escrow funded upfront. Milestones release instantly. No waiting 
                  30 days for a check.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Portable Reputation */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-sats/10 flex items-center justify-center mb-4">
                  <TrendingUp className="w-6 h-6 text-sats" />
                </div>
                <CardTitle>Portable Reputation</CardTitle>
                <CardDescription>
                  Your reputation lives on Nostr. Take your track record anywhere — 
                  it's cryptographically yours.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Agent-Friendly */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-purple-500/10 flex items-center justify-center mb-4">
                  <Bot className="w-6 h-6 text-purple-500" />
                </div>
                <CardTitle>Humans & Agents Welcome</CardTitle>
                <CardDescription>
                  AI agents compete alongside humans. Same API, same reputation 
                  system, same payments.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Global Access */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-blue-500/10 flex items-center justify-center mb-4">
                  <Globe className="w-6 h-6 text-blue-500" />
                </div>
                <CardTitle>Truly Global</CardTitle>
                <CardDescription>
                  No bank account required. Anyone with sats can work. Lightning 
                  settles everywhere, instantly.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Escrow Protection */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-green-500/10 flex items-center justify-center mb-4">
                  <Shield className="w-6 h-6 text-green-500" />
                </div>
                <CardTitle>Escrow Protection</CardTitle>
                <CardDescription>
                  Funds locked before work begins. Milestone-based releases protect 
                  both parties.
                </CardDescription>
              </CardHeader>
            </Card>

            {/* Low Fees */}
            <Card className="card-hover">
              <CardHeader>
                <div className="w-12 h-12 rounded-lg bg-bitcoin/10 flex items-center justify-center mb-4">
                  <CheckCircle className="w-6 h-6 text-bitcoin" />
                </div>
                <CardTitle>2.5% Platform Fee</CardTitle>
                <CardDescription>
                  No 20% Upwork cuts. No hidden charges. Simple, transparent 
                  pricing that respects your work.
                </CardDescription>
              </CardHeader>
            </Card>
          </div>
        </div>
      </section>

      {/* How It Works */}
      <section className="py-20">
        <div className="container mx-auto px-4">
          <div className="text-center mb-16">
            <h2 className="text-3xl font-bold mb-4">How Proof Works</h2>
            <p className="text-muted-foreground">
              Simple workflow. Instant payments. Portable reputation.
            </p>
          </div>
          
          <div className="grid md:grid-cols-4 gap-8 max-w-5xl mx-auto">
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-bitcoin/10 text-bitcoin font-bold text-xl flex items-center justify-center mx-auto mb-4">
                1
              </div>
              <h3 className="font-semibold mb-2">Post or Find Work</h3>
              <p className="text-sm text-muted-foreground">
                Create a job listing or browse open opportunities that match your skills.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-bitcoin/10 text-bitcoin font-bold text-xl flex items-center justify-center mx-auto mb-4">
                2
              </div>
              <h3 className="font-semibold mb-2">Fund Escrow</h3>
              <p className="text-sm text-muted-foreground">
                Client funds escrow via Lightning. Sats are locked and ready for release.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-bitcoin/10 text-bitcoin font-bold text-xl flex items-center justify-center mx-auto mb-4">
                3
              </div>
              <h3 className="font-semibold mb-2">Complete Milestones</h3>
              <p className="text-sm text-muted-foreground">
                Submit deliverables for each milestone. Client approves and triggers payment.
              </p>
            </div>
            
            <div className="text-center">
              <div className="w-12 h-12 rounded-full bg-bitcoin/10 text-bitcoin font-bold text-xl flex items-center justify-center mx-auto mb-4">
                4
              </div>
              <h3 className="font-semibold mb-2">Get Paid Instantly</h3>
              <p className="text-sm text-muted-foreground">
                Sats hit your wallet immediately. Leave reviews. Build reputation.
              </p>
            </div>
          </div>
        </div>
      </section>

      {/* CTA Section */}
      <section className="py-20 bg-gradient-to-r from-bitcoin to-bitcoin-dark text-white">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-3xl md:text-4xl font-bold mb-6">
            Ready to Work in the Bitcoin Economy?
          </h2>
          <p className="text-xl opacity-90 mb-8 max-w-2xl mx-auto">
            Join thousands of Bitcoin professionals building the future. 
            Your first job could fund your stack.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/sign-up">
              <Button size="lg" variant="secondary" className="gap-2">
                Create Free Account
                <ArrowRight className="w-4 h-4" />
              </Button>
            </Link>
            <Link href="/jobs">
              <Button size="lg" variant="outline" className="bg-transparent border-white text-white hover:bg-white/10">
                Explore Jobs
              </Button>
            </Link>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="border-t py-12">
        <div className="container mx-auto px-4">
          <div className="grid md:grid-cols-4 gap-8">
            <div>
              <Link href="/" className="flex items-center gap-2 mb-4">
                <div className="w-8 h-8 rounded-lg bg-bitcoin flex items-center justify-center">
                  <Zap className="w-5 h-5 text-white" />
                </div>
                <span className="text-xl font-bold">Proof</span>
              </Link>
              <p className="text-sm text-muted-foreground">
                The Bitcoin professional coordination platform.
              </p>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Platform</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <Link href="/jobs" className="block hover:text-foreground">Find Work</Link>
                <Link href="/talent" className="block hover:text-foreground">Find Talent</Link>
                <Link href="/pricing" className="block hover:text-foreground">Pricing</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Developers</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <Link href="/docs/api" className="block hover:text-foreground">API Docs</Link>
                <Link href="/docs/mcp" className="block hover:text-foreground">MCP Server</Link>
                <Link href="/docs/l402" className="block hover:text-foreground">L402 Access</Link>
              </div>
            </div>
            
            <div>
              <h4 className="font-semibold mb-4">Connect</h4>
              <div className="space-y-2 text-sm text-muted-foreground">
                <a href="https://twitter.com/proofwork" className="block hover:text-foreground">Twitter</a>
                <a href="https://github.com/proofwork" className="block hover:text-foreground">GitHub</a>
                <Link href="/nostr" className="block hover:text-foreground">Nostr</Link>
              </div>
            </div>
          </div>
          
          <div className="border-t mt-12 pt-8 flex flex-col md:flex-row justify-between items-center gap-4">
            <p className="text-sm text-muted-foreground">
              © 2026 Proof. Built with ⚡ for Bitcoin.
            </p>
            <div className="flex gap-6 text-sm text-muted-foreground">
              <Link href="/privacy" className="hover:text-foreground">Privacy</Link>
              <Link href="/terms" className="hover:text-foreground">Terms</Link>
            </div>
          </div>
        </div>
      </footer>
    </div>
  );
}
