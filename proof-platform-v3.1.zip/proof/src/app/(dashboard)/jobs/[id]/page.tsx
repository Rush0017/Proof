'use client';

import { useState } from 'react';
import Link from 'next/link';
import { 
  ArrowLeft, 
  Zap, 
  MapPin, 
  Clock, 
  Bot, 
  Shield, 
  Star,
  Send,
  CheckCircle,
  AlertCircle,
  Briefcase,
  User
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatSats, formatRelativeTime, getInitials, satsToUsd } from '@/lib/utils';

// Mock job data
const mockJob = {
  id: '1',
  title: 'Lightning Network Developer',
  description: `We're looking for an experienced Lightning Network developer to build and maintain payment infrastructure for our Bitcoin exchange.

## Requirements
- 3+ years experience with Lightning Network (LND or CLN)
- Strong proficiency in Go or Rust
- Understanding of Bitcoin protocol and scripting
- Experience with channel management and liquidity
- Familiarity with BOLT specifications

## Deliverables
1. Payment processing API with WebSocket notifications
2. Automated channel management system
3. Liquidity rebalancing algorithms
4. Comprehensive test suite
5. Documentation and runbooks

## Timeline
- Phase 1: API design and core implementation (2 weeks)
- Phase 2: Channel management (2 weeks)  
- Phase 3: Testing and documentation (1 week)

We prefer candidates who have contributed to open source Lightning projects.`,
  budget_sats: 5000000,
  payment_type: 'milestone',
  status: 'open',
  required_skills: ['Lightning', 'Rust', 'Go', 'Bitcoin', 'API Design'],
  preferred_skills: ['LND', 'CLN', 'Docker', 'Kubernetes'],
  experience_level: 'senior',
  location_requirement: 'remote',
  allows_agents: true,
  escrow_funded: true,
  escrow_amount_sats: 5125000,
  created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
  application_deadline: new Date(Date.now() + 7 * 24 * 60 * 60 * 1000).toISOString(),
  poster: {
    id: 'poster-1',
    display_name: 'Bitcoin Exchange Co',
    avatar_url: null,
    reputation_score: 4.9,
    jobs_posted: 12,
    total_spent_sats: 45000000,
    is_agent: false,
    nip05_verified: true,
    nip05_identifier: 'hiring@btcexchange.co',
  },
  milestones: [
    { title: 'API Design & Core Implementation', amount_sats: 2000000, status: 'pending' },
    { title: 'Channel Management System', amount_sats: 2000000, status: 'pending' },
    { title: 'Testing & Documentation', amount_sats: 1000000, status: 'pending' },
  ],
  proposals_count: 12,
};

export default function JobDetailPage({ params }: { params: { id: string } }) {
  const [showProposalForm, setShowProposalForm] = useState(false);
  const [coverLetter, setCoverLetter] = useState('');
  const [proposedRate, setProposedRate] = useState('');
  const [estimatedDays, setEstimatedDays] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);

  const handleSubmitProposal = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // TODO: Submit proposal to database
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    setIsSubmitting(false);
    setShowProposalForm(false);
    // Show success toast
  };

  return (
    <div className="max-w-4xl mx-auto">
      {/* Back Link */}
      <Link 
        href="/jobs" 
        className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-6"
      >
        <ArrowLeft className="w-4 h-4" />
        Back to Jobs
      </Link>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Main Content */}
        <div className="lg:col-span-2 space-y-6">
          {/* Header */}
          <Card>
            <CardContent className="p-6">
              <div className="flex items-start justify-between gap-4 mb-4">
                <div>
                  <div className="flex items-center gap-2 mb-2">
                    <Badge variant="open">Open</Badge>
                    {mockJob.allows_agents && (
                      <Badge variant="agent" className="gap-1">
                        <Bot className="w-3 h-3" />
                        Agent-Friendly
                      </Badge>
                    )}
                    {mockJob.escrow_funded && (
                      <Badge variant="sats" className="gap-1">
                        <Shield className="w-3 h-3" />
                        Escrow Funded
                      </Badge>
                    )}
                  </div>
                  <h1 className="text-2xl font-bold mb-2">{mockJob.title}</h1>
                  <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                    <span className="flex items-center gap-1">
                      <MapPin className="w-4 h-4" />
                      Remote
                    </span>
                    <span className="flex items-center gap-1">
                      <Clock className="w-4 h-4" />
                      Posted {formatRelativeTime(mockJob.created_at)}
                    </span>
                    <span className="flex items-center gap-1">
                      <Briefcase className="w-4 h-4" />
                      {mockJob.proposals_count} proposals
                    </span>
                  </div>
                </div>
              </div>

              {/* Budget */}
              <div className="p-4 rounded-lg bg-sats/5 border border-sats/20">
                <div className="flex items-center justify-between">
                  <div>
                    <div className="text-sm text-muted-foreground">Budget</div>
                    <div className="text-2xl font-bold text-sats">
                      {formatSats(mockJob.budget_sats)}
                    </div>
                    <div className="text-sm text-muted-foreground">
                      ≈ {satsToUsd(mockJob.budget_sats)}
                    </div>
                  </div>
                  <div className="text-right">
                    <div className="text-sm text-muted-foreground">Payment Type</div>
                    <div className="font-medium capitalize">{mockJob.payment_type}</div>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Description */}
          <Card>
            <CardHeader>
              <CardTitle>Job Description</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="prose prose-sm dark:prose-invert max-w-none">
                {mockJob.description.split('\n').map((line, i) => {
                  if (line.startsWith('## ')) {
                    return <h3 key={i} className="text-lg font-semibold mt-6 mb-3">{line.replace('## ', '')}</h3>;
                  }
                  if (line.startsWith('- ')) {
                    return <li key={i} className="ml-4">{line.replace('- ', '')}</li>;
                  }
                  if (line.match(/^\d\. /)) {
                    return <li key={i} className="ml-4">{line.replace(/^\d\. /, '')}</li>;
                  }
                  if (line.trim() === '') {
                    return <br key={i} />;
                  }
                  return <p key={i} className="mb-2">{line}</p>;
                })}
              </div>
            </CardContent>
          </Card>

          {/* Skills */}
          <Card>
            <CardHeader>
              <CardTitle>Required Skills</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex flex-wrap gap-2 mb-4">
                {mockJob.required_skills.map((skill) => (
                  <Badge key={skill} variant="secondary">{skill}</Badge>
                ))}
              </div>
              {mockJob.preferred_skills.length > 0 && (
                <>
                  <div className="text-sm text-muted-foreground mb-2">Preferred:</div>
                  <div className="flex flex-wrap gap-2">
                    {mockJob.preferred_skills.map((skill) => (
                      <Badge key={skill} variant="outline">{skill}</Badge>
                    ))}
                  </div>
                </>
              )}
            </CardContent>
          </Card>

          {/* Milestones */}
          {mockJob.milestones.length > 0 && (
            <Card>
              <CardHeader>
                <CardTitle>Payment Milestones</CardTitle>
                <CardDescription>
                  Funds are released as each milestone is approved.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <div className="space-y-3">
                  {mockJob.milestones.map((milestone, index) => (
                    <div 
                      key={index}
                      className="flex items-center justify-between p-3 rounded-lg border"
                    >
                      <div className="flex items-center gap-3">
                        <div className="w-8 h-8 rounded-full bg-muted flex items-center justify-center text-sm font-medium">
                          {index + 1}
                        </div>
                        <span className="font-medium">{milestone.title}</span>
                      </div>
                      <div className="text-sats font-medium">
                        {formatSats(milestone.amount_sats)}
                      </div>
                    </div>
                  ))}
                </div>
              </CardContent>
            </Card>
          )}

          {/* Proposal Form */}
          {showProposalForm ? (
            <Card>
              <CardHeader>
                <CardTitle>Submit Your Proposal</CardTitle>
                <CardDescription>
                  Explain why you're the best fit for this job.
                </CardDescription>
              </CardHeader>
              <CardContent>
                <form onSubmit={handleSubmitProposal} className="space-y-4">
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Cover Letter *
                    </label>
                    <textarea
                      value={coverLetter}
                      onChange={(e) => setCoverLetter(e.target.value)}
                      placeholder="Introduce yourself and explain your relevant experience..."
                      className="w-full min-h-[200px] px-3 py-2 rounded-md border bg-background text-sm resize-y focus:outline-none focus:ring-2 focus:ring-ring"
                      required
                    />
                  </div>

                  <div className="grid sm:grid-cols-2 gap-4">
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Your Rate (sats)
                      </label>
                      <div className="relative">
                        <Zap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-bitcoin" />
                        <Input
                          value={proposedRate}
                          onChange={(e) => setProposedRate(e.target.value)}
                          placeholder={mockJob.budget_sats.toString()}
                          className="pl-10"
                        />
                      </div>
                    </div>
                    <div>
                      <label className="block text-sm font-medium mb-2">
                        Estimated Days
                      </label>
                      <Input
                        type="number"
                        value={estimatedDays}
                        onChange={(e) => setEstimatedDays(e.target.value)}
                        placeholder="e.g., 30"
                      />
                    </div>
                  </div>

                  <div className="flex gap-3 pt-4">
                    <Button 
                      type="button" 
                      variant="outline"
                      onClick={() => setShowProposalForm(false)}
                      className="flex-1"
                    >
                      Cancel
                    </Button>
                    <Button 
                      type="submit" 
                      variant="bitcoin"
                      className="flex-1 gap-2"
                      disabled={!coverLetter || isSubmitting}
                      loading={isSubmitting}
                    >
                      <Send className="w-4 h-4" />
                      Submit Proposal
                    </Button>
                  </div>
                </form>
              </CardContent>
            </Card>
          ) : (
            <Button 
              variant="bitcoin" 
              size="lg" 
              className="w-full gap-2"
              onClick={() => setShowProposalForm(true)}
            >
              <Send className="w-4 h-4" />
              Submit a Proposal
            </Button>
          )}
        </div>

        {/* Sidebar */}
        <div className="space-y-6">
          {/* Poster Info */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">About the Client</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-3 mb-4">
                <Avatar className="w-12 h-12">
                  <AvatarImage src={mockJob.poster.avatar_url || undefined} />
                  <AvatarFallback>
                    {getInitials(mockJob.poster.display_name)}
                  </AvatarFallback>
                </Avatar>
                <div>
                  <div className="font-medium">{mockJob.poster.display_name}</div>
                  {mockJob.poster.nip05_verified && (
                    <div className="text-xs text-muted-foreground flex items-center gap-1">
                      <CheckCircle className="w-3 h-3 text-sats" />
                      {mockJob.poster.nip05_identifier}
                    </div>
                  )}
                </div>
              </div>

              <div className="space-y-3 text-sm">
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Rating</span>
                  <span className="flex items-center gap-1">
                    <Star className="w-4 h-4 text-yellow-500 fill-yellow-500" />
                    {mockJob.poster.reputation_score}
                  </span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Jobs Posted</span>
                  <span>{mockJob.poster.jobs_posted}</span>
                </div>
                <div className="flex items-center justify-between">
                  <span className="text-muted-foreground">Total Spent</span>
                  <span className="text-sats">{formatSats(mockJob.poster.total_spent_sats)}</span>
                </div>
              </div>

              <Button variant="outline" className="w-full mt-4 gap-2">
                <User className="w-4 h-4" />
                View Profile
              </Button>
            </CardContent>
          </Card>

          {/* Job Stats */}
          <Card>
            <CardHeader>
              <CardTitle className="text-base">Job Activity</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3 text-sm">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Proposals</span>
                <span>{mockJob.proposals_count}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Deadline</span>
                <span>{new Date(mockJob.application_deadline).toLocaleDateString()}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Experience</span>
                <span className="capitalize">{mockJob.experience_level}</span>
              </div>
            </CardContent>
          </Card>

          {/* Safety Tips */}
          <Card className="bg-muted/50">
            <CardContent className="p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="w-5 h-5 text-muted-foreground shrink-0 mt-0.5" />
                <div className="text-sm">
                  <div className="font-medium mb-1">Safety Tips</div>
                  <ul className="text-muted-foreground space-y-1">
                    <li>• Only work on jobs with funded escrow</li>
                    <li>• Use milestones for large projects</li>
                    <li>• Keep all communication on platform</li>
                  </ul>
                </div>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
