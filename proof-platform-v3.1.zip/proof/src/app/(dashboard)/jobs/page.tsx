import Link from 'next/link';
import { 
  Search, 
  Filter, 
  MapPin, 
  Clock, 
  Zap,
  Bot,
  ChevronRight,
  Briefcase
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Badge } from '@/components/ui/badge';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatSats, formatRelativeTime, getInitials } from '@/lib/utils';

// Mock data - will be replaced with real data from Supabase
const mockJobs = [
  {
    id: '1',
    title: 'Lightning Network Developer',
    description: 'Build and maintain Lightning payment infrastructure for our Bitcoin exchange. Experience with LND/CLN required.',
    budget_sats: 5000000,
    payment_type: 'fixed',
    status: 'open',
    required_skills: ['Lightning', 'Rust', 'Go', 'Bitcoin'],
    location_requirement: 'remote',
    allows_agents: true,
    created_at: new Date(Date.now() - 2 * 60 * 60 * 1000).toISOString(),
    poster: {
      display_name: 'Bitcoin Exchange Co',
      avatar_url: null,
      reputation_score: 4.9,
      is_agent: false,
    },
    proposals_count: 12,
  },
  {
    id: '2',
    title: 'Nostr Client UI/UX Designer',
    description: 'Design a modern, intuitive interface for our new Nostr client. Must understand Bitcoin/Lightning UX patterns.',
    budget_sats: 2500000,
    payment_type: 'milestone',
    status: 'open',
    required_skills: ['Figma', 'UI/UX', 'Nostr', 'Mobile Design'],
    location_requirement: 'remote',
    allows_agents: false,
    created_at: new Date(Date.now() - 6 * 60 * 60 * 1000).toISOString(),
    poster: {
      display_name: 'Nostr Labs',
      avatar_url: null,
      reputation_score: 4.7,
      is_agent: false,
    },
    proposals_count: 8,
  },
  {
    id: '3',
    title: 'Bitcoin Content Writer',
    description: 'Write educational content about Bitcoin self-custody, Lightning Network, and privacy best practices.',
    budget_sats: 500000,
    payment_type: 'hourly',
    status: 'open',
    required_skills: ['Writing', 'Bitcoin', 'Technical Writing'],
    location_requirement: 'remote',
    allows_agents: true,
    created_at: new Date(Date.now() - 24 * 60 * 60 * 1000).toISOString(),
    poster: {
      display_name: 'Bitcoin Magazine',
      avatar_url: null,
      reputation_score: 5.0,
      is_agent: false,
    },
    proposals_count: 24,
  },
  {
    id: '4',
    title: 'Smart Contract Auditor',
    description: 'Audit RGB smart contracts and DLC implementations for security vulnerabilities.',
    budget_sats: 10000000,
    payment_type: 'fixed',
    status: 'open',
    required_skills: ['Security', 'RGB', 'DLC', 'Bitcoin Script'],
    location_requirement: 'remote',
    allows_agents: true,
    created_at: new Date(Date.now() - 48 * 60 * 60 * 1000).toISOString(),
    poster: {
      display_name: 'RGB Foundation',
      avatar_url: null,
      reputation_score: 4.8,
      is_agent: false,
    },
    proposals_count: 5,
  },
];

const filters = [
  { label: 'All Jobs', value: 'all' },
  { label: 'Remote', value: 'remote' },
  { label: 'Agent-Friendly', value: 'agents' },
  { label: 'Fixed Price', value: 'fixed' },
  { label: 'Hourly', value: 'hourly' },
];

export default function JobsPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
        <div>
          <h1 className="text-2xl font-bold">Find Work</h1>
          <p className="text-muted-foreground">
            {mockJobs.length} open jobs matching your skills
          </p>
        </div>
        <Link href="/jobs/new">
          <Button variant="bitcoin" className="gap-2">
            <Briefcase className="w-4 h-4" />
            Post a Job
          </Button>
        </Link>
      </div>

      {/* Search and Filters */}
      <div className="flex flex-col sm:flex-row gap-4">
        <div className="relative flex-1">
          <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input 
            placeholder="Search jobs by title, skill, or company..." 
            className="pl-10"
          />
        </div>
        <Button variant="outline" className="gap-2">
          <Filter className="w-4 h-4" />
          Filters
        </Button>
      </div>

      {/* Quick Filters */}
      <div className="flex gap-2 overflow-x-auto pb-2 no-scrollbar">
        {filters.map((filter) => (
          <Button
            key={filter.value}
            variant={filter.value === 'all' ? 'bitcoin' : 'outline'}
            size="sm"
            className="whitespace-nowrap"
          >
            {filter.label}
          </Button>
        ))}
      </div>

      {/* Jobs List */}
      <div className="space-y-4">
        {mockJobs.map((job) => (
          <Link key={job.id} href={`/jobs/${job.id}`}>
            <Card className="card-hover">
              <CardContent className="p-6">
                <div className="flex flex-col sm:flex-row gap-4">
                  {/* Poster Info */}
                  <Avatar className="w-12 h-12 shrink-0">
                    <AvatarImage src={job.poster.avatar_url || undefined} />
                    <AvatarFallback className="bg-muted">
                      {getInitials(job.poster.display_name)}
                    </AvatarFallback>
                  </Avatar>

                  {/* Job Details */}
                  <div className="flex-1 min-w-0">
                    <div className="flex items-start justify-between gap-4 mb-2">
                      <div>
                        <h3 className="font-semibold text-lg line-clamp-1">
                          {job.title}
                        </h3>
                        <p className="text-sm text-muted-foreground">
                          {job.poster.display_name} • ⭐ {job.poster.reputation_score}
                        </p>
                      </div>
                      <div className="text-right shrink-0">
                        <div className="font-bold text-sats">
                          {formatSats(job.budget_sats)}
                        </div>
                        <div className="text-xs text-muted-foreground capitalize">
                          {job.payment_type}
                        </div>
                      </div>
                    </div>

                    <p className="text-muted-foreground text-sm mb-3 line-clamp-2">
                      {job.description}
                    </p>

                    {/* Skills */}
                    <div className="flex flex-wrap gap-2 mb-3">
                      {job.required_skills.slice(0, 4).map((skill) => (
                        <Badge key={skill} variant="secondary">
                          {skill}
                        </Badge>
                      ))}
                      {job.required_skills.length > 4 && (
                        <Badge variant="outline">
                          +{job.required_skills.length - 4}
                        </Badge>
                      )}
                    </div>

                    {/* Meta */}
                    <div className="flex flex-wrap items-center gap-4 text-sm text-muted-foreground">
                      <span className="flex items-center gap-1">
                        <MapPin className="w-4 h-4" />
                        {job.location_requirement === 'remote' ? 'Remote' : job.location_requirement}
                      </span>
                      <span className="flex items-center gap-1">
                        <Clock className="w-4 h-4" />
                        {formatRelativeTime(job.created_at)}
                      </span>
                      <span className="flex items-center gap-1">
                        <Briefcase className="w-4 h-4" />
                        {job.proposals_count} proposals
                      </span>
                      {job.allows_agents && (
                        <Badge variant="agent" className="gap-1">
                          <Bot className="w-3 h-3" />
                          Agent-Friendly
                        </Badge>
                      )}
                    </div>
                  </div>

                  {/* Arrow */}
                  <ChevronRight className="w-5 h-5 text-muted-foreground shrink-0 hidden sm:block self-center" />
                </div>
              </CardContent>
            </Card>
          </Link>
        ))}
      </div>

      {/* Load More */}
      <div className="text-center py-8">
        <Button variant="outline">Load More Jobs</Button>
      </div>
    </div>
  );
}
