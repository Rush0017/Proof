'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ArrowLeft, Zap, Plus, X, Info } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatSats, parseSats } from '@/lib/utils';

const SKILL_SUGGESTIONS = [
  'Lightning', 'Bitcoin', 'Rust', 'Go', 'TypeScript', 'React', 
  'Node.js', 'Python', 'Nostr', 'UI/UX', 'Technical Writing',
  'Security', 'DLC', 'RGB', 'Mobile', 'iOS', 'Android'
];

export default function NewJobPage() {
  const router = useRouter();
  const [isSubmitting, setIsSubmitting] = useState(false);
  
  // Form state
  const [title, setTitle] = useState('');
  const [description, setDescription] = useState('');
  const [budgetInput, setBudgetInput] = useState('');
  const [paymentType, setPaymentType] = useState<'fixed' | 'hourly' | 'milestone'>('fixed');
  const [skills, setSkills] = useState<string[]>([]);
  const [newSkill, setNewSkill] = useState('');
  const [allowsAgents, setAllowsAgents] = useState(true);
  const [experienceLevel, setExperienceLevel] = useState<string>('intermediate');
  
  const budgetSats = parseSats(budgetInput) || 0;
  const platformFee = Math.ceil(budgetSats * 0.025);
  const totalCost = budgetSats + platformFee;

  const addSkill = (skill: string) => {
    const normalized = skill.trim();
    if (normalized && !skills.includes(normalized)) {
      setSkills([...skills, normalized]);
    }
    setNewSkill('');
  };

  const removeSkill = (skill: string) => {
    setSkills(skills.filter(s => s !== skill));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsSubmitting(true);
    
    // TODO: Create job in database
    console.log({
      title,
      description,
      budget_sats: budgetSats,
      payment_type: paymentType,
      required_skills: skills,
      allows_agents: allowsAgents,
      experience_level: experienceLevel,
    });
    
    // Simulate API call
    await new Promise(resolve => setTimeout(resolve, 1000));
    
    router.push('/jobs');
  };

  return (
    <div className="max-w-3xl mx-auto">
      {/* Header */}
      <div className="mb-8">
        <Link 
          href="/jobs" 
          className="inline-flex items-center gap-2 text-muted-foreground hover:text-foreground mb-4"
        >
          <ArrowLeft className="w-4 h-4" />
          Back to Jobs
        </Link>
        <h1 className="text-2xl font-bold">Post a New Job</h1>
        <p className="text-muted-foreground">
          Create a job listing to find the perfect talent for your project.
        </p>
      </div>

      <form onSubmit={handleSubmit} className="space-y-6">
        {/* Basic Info */}
        <Card>
          <CardHeader>
            <CardTitle>Job Details</CardTitle>
            <CardDescription>
              Describe the work you need done.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Job Title *
              </label>
              <Input
                value={title}
                onChange={(e) => setTitle(e.target.value)}
                placeholder="e.g., Lightning Network Developer"
                required
              />
            </div>
            
            <div>
              <label className="block text-sm font-medium mb-2">
                Description *
              </label>
              <textarea
                value={description}
                onChange={(e) => setDescription(e.target.value)}
                placeholder="Describe the project, requirements, and deliverables..."
                className="w-full min-h-[150px] px-3 py-2 rounded-md border bg-background text-sm resize-y focus:outline-none focus:ring-2 focus:ring-ring"
                required
              />
            </div>
          </CardContent>
        </Card>

        {/* Budget & Payment */}
        <Card>
          <CardHeader>
            <CardTitle>Budget & Payment</CardTitle>
            <CardDescription>
              Set your budget and how you want to pay.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Payment Type
              </label>
              <div className="grid grid-cols-3 gap-3">
                {(['fixed', 'hourly', 'milestone'] as const).map((type) => (
                  <button
                    key={type}
                    type="button"
                    onClick={() => setPaymentType(type)}
                    className={`p-3 rounded-lg border text-center transition-colors ${
                      paymentType === type
                        ? 'border-bitcoin bg-bitcoin/10 text-bitcoin'
                        : 'hover:bg-muted'
                    }`}
                  >
                    <div className="font-medium capitalize">{type}</div>
                    <div className="text-xs text-muted-foreground">
                      {type === 'fixed' && 'One-time payment'}
                      {type === 'hourly' && 'Pay per hour'}
                      {type === 'milestone' && 'Pay per milestone'}
                    </div>
                  </button>
                ))}
              </div>
            </div>

            <div>
              <label className="block text-sm font-medium mb-2">
                {paymentType === 'hourly' ? 'Hourly Rate' : 'Total Budget'} (sats) *
              </label>
              <div className="relative">
                <Zap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-bitcoin" />
                <Input
                  value={budgetInput}
                  onChange={(e) => setBudgetInput(e.target.value)}
                  placeholder="e.g., 1000000 or 1M"
                  className="pl-10"
                  required
                />
              </div>
              {budgetSats > 0 && (
                <p className="text-sm text-muted-foreground mt-1">
                  = {formatSats(budgetSats)} (≈ ${(budgetSats / 100000).toFixed(2)} USD)
                </p>
              )}
            </div>

            {budgetSats > 0 && (
              <div className="p-4 rounded-lg bg-muted/50 space-y-2">
                <div className="flex justify-between text-sm">
                  <span>Job Budget</span>
                  <span>{formatSats(budgetSats)}</span>
                </div>
                <div className="flex justify-between text-sm">
                  <span>Platform Fee (2.5%)</span>
                  <span>{formatSats(platformFee)}</span>
                </div>
                <div className="flex justify-between font-medium pt-2 border-t">
                  <span>Total to Fund Escrow</span>
                  <span className="text-bitcoin">{formatSats(totalCost)}</span>
                </div>
              </div>
            )}
          </CardContent>
        </Card>

        {/* Skills */}
        <Card>
          <CardHeader>
            <CardTitle>Required Skills</CardTitle>
            <CardDescription>
              What skills should candidates have?
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex gap-2">
              <Input
                value={newSkill}
                onChange={(e) => setNewSkill(e.target.value)}
                placeholder="Add a skill..."
                onKeyDown={(e) => {
                  if (e.key === 'Enter') {
                    e.preventDefault();
                    addSkill(newSkill);
                  }
                }}
              />
              <Button 
                type="button" 
                variant="outline"
                onClick={() => addSkill(newSkill)}
              >
                <Plus className="w-4 h-4" />
              </Button>
            </div>

            {skills.length > 0 && (
              <div className="flex flex-wrap gap-2">
                {skills.map((skill) => (
                  <Badge key={skill} variant="secondary" className="gap-1 pr-1">
                    {skill}
                    <button
                      type="button"
                      onClick={() => removeSkill(skill)}
                      className="ml-1 hover:bg-muted rounded"
                    >
                      <X className="w-3 h-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            <div>
              <p className="text-sm text-muted-foreground mb-2">Suggestions:</p>
              <div className="flex flex-wrap gap-2">
                {SKILL_SUGGESTIONS.filter(s => !skills.includes(s)).slice(0, 8).map((skill) => (
                  <button
                    key={skill}
                    type="button"
                    onClick={() => addSkill(skill)}
                    className="px-2 py-1 text-xs rounded border hover:bg-muted transition-colors"
                  >
                    + {skill}
                  </button>
                ))}
              </div>
            </div>
          </CardContent>
        </Card>

        {/* Preferences */}
        <Card>
          <CardHeader>
            <CardTitle>Preferences</CardTitle>
            <CardDescription>
              Additional requirements for candidates.
            </CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">
                Experience Level
              </label>
              <div className="grid grid-cols-4 gap-2">
                {['entry', 'intermediate', 'senior', 'expert'].map((level) => (
                  <button
                    key={level}
                    type="button"
                    onClick={() => setExperienceLevel(level)}
                    className={`p-2 rounded-lg border text-sm capitalize transition-colors ${
                      experienceLevel === level
                        ? 'border-bitcoin bg-bitcoin/10 text-bitcoin'
                        : 'hover:bg-muted'
                    }`}
                  >
                    {level}
                  </button>
                ))}
              </div>
            </div>

            <div className="flex items-center justify-between p-4 rounded-lg border">
              <div className="flex items-start gap-3">
                <div className="p-2 rounded-lg bg-purple-500/10">
                  <Info className="w-4 h-4 text-purple-500" />
                </div>
                <div>
                  <div className="font-medium">Allow AI Agent Applications</div>
                  <div className="text-sm text-muted-foreground">
                    AI agents can compete alongside human workers for this job.
                  </div>
                </div>
              </div>
              <button
                type="button"
                onClick={() => setAllowsAgents(!allowsAgents)}
                className={`w-12 h-6 rounded-full transition-colors ${
                  allowsAgents ? 'bg-bitcoin' : 'bg-muted'
                }`}
              >
                <div 
                  className={`w-5 h-5 rounded-full bg-white shadow transition-transform ${
                    allowsAgents ? 'translate-x-6' : 'translate-x-0.5'
                  }`}
                />
              </button>
            </div>
          </CardContent>
        </Card>

        {/* Submit */}
        <div className="flex gap-4">
          <Button 
            type="button" 
            variant="outline" 
            className="flex-1"
            onClick={() => router.back()}
          >
            Cancel
          </Button>
          <Button 
            type="submit" 
            variant="bitcoin" 
            className="flex-1 gap-2"
            disabled={!title || !description || budgetSats <= 0 || isSubmitting}
            loading={isSubmitting}
          >
            <Zap className="w-4 h-4" />
            Post Job & Fund Escrow
          </Button>
        </div>
      </form>
    </div>
  );
}
