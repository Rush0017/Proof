import Link from 'next/link';
import { 
  Zap, 
  Briefcase, 
  TrendingUp, 
  Clock, 
  ArrowUpRight,
  ArrowDownRight,
  CheckCircle,
  AlertCircle,
  Star,
  Bot
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { Avatar, AvatarFallback, AvatarImage } from '@/components/ui/avatar';
import { formatSats, formatRelativeTime, getInitials } from '@/lib/utils';

// Mock data
const stats = {
  balance: 245000,
  earned_this_month: 1500000,
  earned_change: 12.5,
  active_jobs: 3,
  pending_proposals: 5,
  reputation: 4.8,
};

const activeJobs = [
  {
    id: '1',
    title: 'Lightning Integration for E-commerce',
    client: 'ShopBTC',
    status: 'in_progress',
    earned: 500000,
    total: 1000000,
    next_milestone: 'Payment API',
    due: '3 days',
  },
  {
    id: '2',
    title: 'Nostr Client Bug Fixes',
    client: 'NostrLabs',
    status: 'review',
    earned: 200000,
    total: 250000,
    next_milestone: 'Final Review',
    due: '1 day',
  },
];

const recentActivity = [
  {
    id: '1',
    type: 'payment_received',
    title: 'Payment received',
    description: 'Milestone completed for Lightning Integration',
    amount: 250000,
    time: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: '2',
    type: 'proposal_accepted',
    title: 'Proposal accepted',
    description: 'Your proposal for Nostr Client Bug Fixes was accepted',
    time: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
  {
    id: '3',
    type: 'review_received',
    title: 'New review',
    description: 'You received a 5-star review from Bitcoin Exchange Co',
    rating: 5,
    time: new Date(Date.now() - 48 * 60 * 60 * 1000),
  },
];

const recommendedJobs = [
  {
    id: '3',
    title: 'Bitcoin Wallet UI Redesign',
    budget_sats: 2000000,
    skills: ['UI/UX', 'Figma', 'Bitcoin'],
    match: 95,
    allows_agents: false,
  },
  {
    id: '4',
    title: 'LND Channel Management Tool',
    budget_sats: 3500000,
    skills: ['Lightning', 'Go', 'React'],
    match: 88,
    allows_agents: true,
  },
];

export default function DashboardPage() {
  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Dashboard</h1>
        <p className="text-muted-foreground">
          Welcome back! Here's what's happening with your work.
        </p>
      </div>

      {/* Stats Grid */}
      <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Available Balance</p>
                <p className="text-2xl font-bold text-sats">{formatSats(stats.balance)}</p>
              </div>
              <div className="p-3 rounded-full bg-sats/10">
                <Zap className="w-5 h-5 text-sats" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Earned This Month</p>
                <p className="text-2xl font-bold">{formatSats(stats.earned_this_month)}</p>
                <p className="text-xs text-sats flex items-center gap-1 mt-1">
                  <ArrowUpRight className="w-3 h-3" />
                  +{stats.earned_change}% from last month
                </p>
              </div>
              <div className="p-3 rounded-full bg-green-500/10">
                <TrendingUp className="w-5 h-5 text-green-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Active Jobs</p>
                <p className="text-2xl font-bold">{stats.active_jobs}</p>
                <p className="text-xs text-muted-foreground mt-1">
                  {stats.pending_proposals} pending proposals
                </p>
              </div>
              <div className="p-3 rounded-full bg-blue-500/10">
                <Briefcase className="w-5 h-5 text-blue-500" />
              </div>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardContent className="p-6">
            <div className="flex items-center justify-between">
              <div>
                <p className="text-sm text-muted-foreground">Reputation</p>
                <p className="text-2xl font-bold flex items-center gap-1">
                  <Star className="w-5 h-5 text-yellow-500 fill-yellow-500" />
                  {stats.reputation}
                </p>
                <p className="text-xs text-muted-foreground mt-1">
                  Based on 23 reviews
                </p>
              </div>
              <div className="p-3 rounded-full bg-yellow-500/10">
                <Star className="w-5 h-5 text-yellow-500" />
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Active Jobs */}
        <div className="lg:col-span-2 space-y-6">
          <Card>
            <CardHeader className="flex flex-row items-center justify-between">
              <div>
                <CardTitle>Active Jobs</CardTitle>
                <CardDescription>Jobs you're currently working on</CardDescription>
              </div>
              <Link href="/jobs?filter=active">
                <Button variant="ghost" size="sm">View All</Button>
              </Link>
            </CardHeader>
            <CardContent>
              {activeJobs.length > 0 ? (
                <div className="space-y-4">
                  {activeJobs.map((job) => (
                    <Link key={job.id} href={`/jobs/${job.id}`}>
                      <div className="p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                        <div className="flex items-start justify-between mb-3">
                          <div>
                            <h3 className="font-medium">{job.title}</h3>
                            <p className="text-sm text-muted-foreground">{job.client}</p>
                          </div>
                          <Badge variant={job.status === 'review' ? 'pending' : 'in-progress'}>
                            {job.status === 'review' ? 'In Review' : 'In Progress'}
                          </Badge>
                        </div>
                        
                        {/* Progress bar */}
                        <div className="mb-3">
                          <div className="flex justify-between text-sm mb-1">
                            <span className="text-muted-foreground">Progress</span>
                            <span className="text-sats">{formatSats(job.earned)} / {formatSats(job.total)}</span>
                          </div>
                          <div className="h-2 bg-muted rounded-full overflow-hidden">
                            <div 
                              className="h-full bg-sats rounded-full transition-all"
                              style={{ width: `${(job.earned / job.total) * 100}%` }}
                            />
                          </div>
                        </div>

                        <div className="flex items-center justify-between text-sm">
                          <span className="text-muted-foreground">
                            Next: {job.next_milestone}
                          </span>
                          <span className="flex items-center gap-1 text-muted-foreground">
                            <Clock className="w-3 h-3" />
                            Due in {job.due}
                          </span>
                        </div>
                      </div>
                    </Link>
                  ))}
                </div>
              ) : (
                <div className="text-center py-8">
                  <Briefcase className="w-12 h-12 text-muted-foreground mx-auto mb-3" />
                  <p className="text-muted-foreground mb-4">No active jobs</p>
                  <Link href="/jobs">
                    <Button variant="bitcoin">Find Work</Button>
                  </Link>
                </div>
              )}
            </CardContent>
          </Card>

          {/* Recommended Jobs */}
          <Card>
            <CardHeader>
              <CardTitle>Recommended for You</CardTitle>
              <CardDescription>Jobs matching your skills</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-3">
                {recommendedJobs.map((job) => (
                  <Link key={job.id} href={`/jobs/${job.id}`}>
                    <div className="p-4 rounded-lg border hover:bg-muted/50 transition-colors">
                      <div className="flex items-start justify-between mb-2">
                        <div>
                          <div className="flex items-center gap-2">
                            <h3 className="font-medium">{job.title}</h3>
                            {job.allows_agents && (
                              <Badge variant="agent" className="gap-1">
                                <Bot className="w-3 h-3" />
                              </Badge>
                            )}
                          </div>
                          <div className="flex flex-wrap gap-1 mt-2">
                            {job.skills.map((skill) => (
                              <Badge key={skill} variant="secondary" className="text-xs">
                                {skill}
                              </Badge>
                            ))}
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="font-medium text-sats">{formatSats(job.budget_sats)}</div>
                          <div className="text-xs text-green-500">{job.match}% match</div>
                        </div>
                      </div>
                    </div>
                  </Link>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>

        {/* Activity Feed */}
        <div>
          <Card>
            <CardHeader>
              <CardTitle>Recent Activity</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {recentActivity.map((activity) => (
                  <div key={activity.id} className="flex gap-3">
                    <div className={`p-2 rounded-full shrink-0 ${
                      activity.type === 'payment_received' ? 'bg-sats/10' :
                      activity.type === 'proposal_accepted' ? 'bg-green-500/10' :
                      'bg-yellow-500/10'
                    }`}>
                      {activity.type === 'payment_received' && (
                        <Zap className="w-4 h-4 text-sats" />
                      )}
                      {activity.type === 'proposal_accepted' && (
                        <CheckCircle className="w-4 h-4 text-green-500" />
                      )}
                      {activity.type === 'review_received' && (
                        <Star className="w-4 h-4 text-yellow-500" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <p className="font-medium text-sm">{activity.title}</p>
                      <p className="text-xs text-muted-foreground line-clamp-1">
                        {activity.description}
                      </p>
                      <div className="flex items-center gap-2 mt-1">
                        {activity.amount && (
                          <span className="text-xs text-sats font-medium">
                            +{formatSats(activity.amount)}
                          </span>
                        )}
                        {activity.rating && (
                          <span className="text-xs flex items-center gap-0.5">
                            {Array.from({ length: activity.rating }).map((_, i) => (
                              <Star key={i} className="w-3 h-3 text-yellow-500 fill-yellow-500" />
                            ))}
                          </span>
                        )}
                        <span className="text-xs text-muted-foreground">
                          {formatRelativeTime(activity.time)}
                        </span>
                      </div>
                    </div>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  );
}
