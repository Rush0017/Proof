'use client';

import { useState } from 'react';
import { 
  Zap, 
  ArrowUpRight, 
  ArrowDownLeft, 
  Copy, 
  ExternalLink,
  QrCode,
  Wallet,
  Clock,
  CheckCircle,
  AlertCircle,
  RefreshCw
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from '@/components/ui/card';
import { Badge } from '@/components/ui/badge';
import { formatSats, formatRelativeTime, satsToUsd } from '@/lib/utils';

// Mock data
const walletData = {
  balance: 245000,
  pending_incoming: 50000,
  pending_outgoing: 0,
  lightning_address: 'user@proof.work',
  nwc_connected: true,
};

const transactions = [
  {
    id: '1',
    type: 'incoming',
    description: 'Milestone payment - Lightning Integration',
    amount: 250000,
    status: 'completed',
    from: 'ShopBTC',
    time: new Date(Date.now() - 2 * 60 * 60 * 1000),
  },
  {
    id: '2',
    type: 'outgoing',
    description: 'Withdrawal to external wallet',
    amount: 100000,
    status: 'completed',
    to: 'lnbc...',
    time: new Date(Date.now() - 24 * 60 * 60 * 1000),
  },
  {
    id: '3',
    type: 'incoming',
    description: 'Job completion - Nostr DM Feature',
    amount: 150000,
    status: 'completed',
    from: 'NostrLabs',
    time: new Date(Date.now() - 48 * 60 * 60 * 1000),
  },
  {
    id: '4',
    type: 'incoming',
    description: 'Referral bonus',
    amount: 10000,
    status: 'completed',
    from: 'Proof Platform',
    time: new Date(Date.now() - 72 * 60 * 60 * 1000),
  },
];

export default function WalletPage() {
  const [activeTab, setActiveTab] = useState<'deposit' | 'withdraw'>('deposit');
  const [withdrawAmount, setWithdrawAmount] = useState('');
  const [withdrawAddress, setWithdrawAddress] = useState('');
  const [showQR, setShowQR] = useState(false);

  const copyToClipboard = (text: string) => {
    navigator.clipboard.writeText(text);
    // TODO: Show toast
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div>
        <h1 className="text-2xl font-bold">Wallet</h1>
        <p className="text-muted-foreground">
          Manage your sats, deposits, and withdrawals.
        </p>
      </div>

      {/* Balance Card */}
      <Card className="bg-gradient-to-br from-bitcoin/10 to-lightning/10 border-bitcoin/20">
        <CardContent className="p-6">
          <div className="flex flex-col md:flex-row md:items-center justify-between gap-6">
            <div>
              <p className="text-sm text-muted-foreground mb-1">Available Balance</p>
              <div className="text-4xl font-bold text-bitcoin mb-1">
                {formatSats(walletData.balance)}
              </div>
              <p className="text-muted-foreground">
                ≈ {satsToUsd(walletData.balance)}
              </p>
              
              {walletData.pending_incoming > 0 && (
                <div className="flex items-center gap-2 mt-3 text-sm text-yellow-600">
                  <Clock className="w-4 h-4" />
                  {formatSats(walletData.pending_incoming)} pending
                </div>
              )}
            </div>

            <div className="flex gap-3">
              <Button 
                variant="bitcoin" 
                size="lg" 
                className="gap-2"
                onClick={() => setActiveTab('deposit')}
              >
                <ArrowDownLeft className="w-4 h-4" />
                Deposit
              </Button>
              <Button 
                variant="outline" 
                size="lg" 
                className="gap-2"
                onClick={() => setActiveTab('withdraw')}
              >
                <ArrowUpRight className="w-4 h-4" />
                Withdraw
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <div className="grid lg:grid-cols-3 gap-6">
        {/* Deposit/Withdraw Panel */}
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <div className="flex gap-4 border-b -mx-6 px-6 -mt-6 pt-6">
                <button
                  onClick={() => setActiveTab('deposit')}
                  className={`pb-3 px-1 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'deposit'
                      ? 'border-bitcoin text-bitcoin'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Deposit
                </button>
                <button
                  onClick={() => setActiveTab('withdraw')}
                  className={`pb-3 px-1 text-sm font-medium border-b-2 transition-colors ${
                    activeTab === 'withdraw'
                      ? 'border-bitcoin text-bitcoin'
                      : 'border-transparent text-muted-foreground hover:text-foreground'
                  }`}
                >
                  Withdraw
                </button>
              </div>
            </CardHeader>
            <CardContent>
              {activeTab === 'deposit' ? (
                <div className="space-y-6">
                  {/* Lightning Address */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Your Lightning Address
                    </label>
                    <div className="flex gap-2">
                      <div className="flex-1 flex items-center gap-2 px-3 py-2 bg-muted rounded-lg">
                        <Zap className="w-4 h-4 text-lightning" />
                        <span className="font-mono text-sm">{walletData.lightning_address}</span>
                      </div>
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => copyToClipboard(walletData.lightning_address)}
                      >
                        <Copy className="w-4 h-4" />
                      </Button>
                      <Button 
                        variant="outline" 
                        size="icon"
                        onClick={() => setShowQR(!showQR)}
                      >
                        <QrCode className="w-4 h-4" />
                      </Button>
                    </div>
                    <p className="text-xs text-muted-foreground mt-2">
                      Send sats to this address from any Lightning wallet.
                    </p>
                  </div>

                  {showQR && (
                    <div className="flex justify-center p-6 bg-white rounded-lg">
                      {/* Placeholder for QR code */}
                      <div className="w-48 h-48 bg-muted flex items-center justify-center rounded">
                        <QrCode className="w-12 h-12 text-muted-foreground" />
                      </div>
                    </div>
                  )}

                  {/* NWC Connection */}
                  <div className="p-4 rounded-lg border">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className={`p-2 rounded-lg ${walletData.nwc_connected ? 'bg-green-500/10' : 'bg-muted'}`}>
                          <Wallet className={`w-5 h-5 ${walletData.nwc_connected ? 'text-green-500' : 'text-muted-foreground'}`} />
                        </div>
                        <div>
                          <div className="font-medium">Nostr Wallet Connect</div>
                          <div className="text-sm text-muted-foreground">
                            {walletData.nwc_connected ? 'Connected to Alby' : 'Connect your wallet for seamless payments'}
                          </div>
                        </div>
                      </div>
                      <Button variant={walletData.nwc_connected ? 'outline' : 'bitcoin'} size="sm">
                        {walletData.nwc_connected ? 'Manage' : 'Connect'}
                      </Button>
                    </div>
                  </div>
                </div>
              ) : (
                <div className="space-y-6">
                  {/* Withdraw Amount */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Amount (sats)
                    </label>
                    <div className="relative">
                      <Zap className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-bitcoin" />
                      <Input
                        value={withdrawAmount}
                        onChange={(e) => setWithdrawAmount(e.target.value)}
                        placeholder="0"
                        className="pl-10"
                      />
                    </div>
                    <div className="flex gap-2 mt-2">
                      {[25, 50, 75, 100].map((pct) => (
                        <Button
                          key={pct}
                          variant="outline"
                          size="sm"
                          onClick={() => setWithdrawAmount(Math.floor(walletData.balance * pct / 100).toString())}
                        >
                          {pct}%
                        </Button>
                      ))}
                    </div>
                  </div>

                  {/* Withdraw Destination */}
                  <div>
                    <label className="block text-sm font-medium mb-2">
                      Lightning Address or Invoice
                    </label>
                    <Input
                      value={withdrawAddress}
                      onChange={(e) => setWithdrawAddress(e.target.value)}
                      placeholder="user@wallet.com or lnbc..."
                    />
                  </div>

                  {/* Fee estimate */}
                  {withdrawAmount && (
                    <div className="p-4 rounded-lg bg-muted/50 space-y-2 text-sm">
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Amount</span>
                        <span>{formatSats(parseInt(withdrawAmount) || 0)}</span>
                      </div>
                      <div className="flex justify-between">
                        <span className="text-muted-foreground">Network fee (est.)</span>
                        <span>~10 sats</span>
                      </div>
                      <div className="flex justify-between font-medium pt-2 border-t">
                        <span>You'll receive</span>
                        <span className="text-sats">{formatSats((parseInt(withdrawAmount) || 0) - 10)}</span>
                      </div>
                    </div>
                  )}

                  <Button 
                    variant="bitcoin" 
                    className="w-full gap-2"
                    disabled={!withdrawAmount || !withdrawAddress}
                  >
                    <ArrowUpRight className="w-4 h-4" />
                    Withdraw {withdrawAmount ? formatSats(parseInt(withdrawAmount)) : ''}
                  </Button>
                </div>
              )}
            </CardContent>
          </Card>
        </div>

        {/* Quick Stats */}
        <div className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle className="text-base">This Month</CardTitle>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Earned</span>
                <span className="text-sats font-medium">+{formatSats(1500000)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Withdrawn</span>
                <span className="font-medium">-{formatSats(100000)}</span>
              </div>
              <div className="flex items-center justify-between">
                <span className="text-muted-foreground">Platform fees</span>
                <span className="font-medium">-{formatSats(37500)}</span>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle className="text-base">Payment Methods</CardTitle>
            </CardHeader>
            <CardContent className="space-y-3">
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Zap className="w-5 h-5 text-lightning" />
                <div className="flex-1">
                  <div className="font-medium text-sm">Lightning Address</div>
                  <div className="text-xs text-muted-foreground">Instant deposits & withdrawals</div>
                </div>
                <CheckCircle className="w-4 h-4 text-green-500" />
              </div>
              <div className="flex items-center gap-3 p-3 rounded-lg bg-muted/50">
                <Wallet className="w-5 h-5 text-purple-500" />
                <div className="flex-1">
                  <div className="font-medium text-sm">Nostr Wallet Connect</div>
                  <div className="text-xs text-muted-foreground">One-click payments</div>
                </div>
                {walletData.nwc_connected ? (
                  <CheckCircle className="w-4 h-4 text-green-500" />
                ) : (
                  <Button variant="ghost" size="sm">Setup</Button>
                )}
              </div>
            </CardContent>
          </Card>
        </div>
      </div>

      {/* Transaction History */}
      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Transaction History</CardTitle>
            <CardDescription>Your recent payments and withdrawals</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <RefreshCw className="w-4 h-4" />
            Refresh
          </Button>
        </CardHeader>
        <CardContent>
          <div className="space-y-3">
            {transactions.map((tx) => (
              <div 
                key={tx.id}
                className="flex items-center justify-between p-4 rounded-lg border"
              >
                <div className="flex items-center gap-4">
                  <div className={`p-2 rounded-full ${
                    tx.type === 'incoming' ? 'bg-sats/10' : 'bg-muted'
                  }`}>
                    {tx.type === 'incoming' ? (
                      <ArrowDownLeft className="w-4 h-4 text-sats" />
                    ) : (
                      <ArrowUpRight className="w-4 h-4 text-muted-foreground" />
                    )}
                  </div>
                  <div>
                    <div className="font-medium">{tx.description}</div>
                    <div className="text-sm text-muted-foreground">
                      {tx.from ? `From ${tx.from}` : tx.to ? `To ${tx.to.slice(0, 20)}...` : ''}
                      {' • '}
                      {formatRelativeTime(tx.time)}
                    </div>
                  </div>
                </div>
                <div className="text-right">
                  <div className={`font-medium ${tx.type === 'incoming' ? 'text-sats' : ''}`}>
                    {tx.type === 'incoming' ? '+' : '-'}{formatSats(tx.amount)}
                  </div>
                  <Badge variant={tx.status === 'completed' ? 'verified' : 'pending'}>
                    {tx.status}
                  </Badge>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  );
}
