import type { Metadata } from 'next';
import { Inter, JetBrains_Mono } from 'next/font/google';
import { ClerkProvider } from '@clerk/nextjs';
import { ThemeProvider } from '@/components/providers/theme-provider';
import { Toaster } from '@/components/ui/toaster';
import './globals.css';

const inter = Inter({
  subsets: ['latin'],
  variable: '--font-inter',
});

const mono = JetBrains_Mono({
  subsets: ['latin'],
  variable: '--font-mono',
});

export const metadata: Metadata = {
  title: {
    default: 'Proof - Bitcoin Professional Network',
    template: '%s | Proof',
  },
  description:
    'The Bitcoin professional coordination platform. Find work, hire talent, build reputation — all settled in sats.',
  keywords: [
    'bitcoin',
    'jobs',
    'freelance',
    'lightning',
    'professional network',
    'hiring',
    'remote work',
  ],
  authors: [{ name: 'Proof' }],
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://proof.work',
    siteName: 'Proof',
    title: 'Proof - Bitcoin Professional Network',
    description:
      'The Bitcoin professional coordination platform. Find work, hire talent, build reputation — all settled in sats.',
    images: [
      {
        url: '/og-image.png',
        width: 1200,
        height: 630,
        alt: 'Proof - Bitcoin Professional Network',
      },
    ],
  },
  twitter: {
    card: 'summary_large_image',
    title: 'Proof - Bitcoin Professional Network',
    description:
      'The Bitcoin professional coordination platform. Find work, hire talent, build reputation — all settled in sats.',
    images: ['/og-image.png'],
    creator: '@proofwork',
  },
  robots: {
    index: true,
    follow: true,
  },
  manifest: '/manifest.json',
  icons: {
    icon: '/favicon.ico',
    apple: '/apple-touch-icon.png',
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <ClerkProvider>
      <html lang="en" suppressHydrationWarning>
        <body className={`${inter.variable} ${mono.variable} font-sans antialiased`}>
          <ThemeProvider
            attribute="class"
            defaultTheme="system"
            enableSystem
            disableTransitionOnChange
          >
            {children}
            <Toaster />
          </ThemeProvider>
        </body>
      </html>
    </ClerkProvider>
  );
}
