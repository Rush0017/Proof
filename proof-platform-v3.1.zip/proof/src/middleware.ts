import { authMiddleware } from '@clerk/nextjs';

export default authMiddleware({
  // Public routes that don't require authentication
  publicRoutes: [
    '/',
    '/sign-in(.*)',
    '/sign-up(.*)',
    '/jobs',
    '/jobs/(.*)',
    '/talent',
    '/talent/(.*)',
    '/about',
    '/pricing',
    '/docs(.*)',
    '/api/webhooks(.*)',
    '/api/l402(.*)', // L402 endpoints use payment-based auth
    '/api/jobs', // Public job listing
    '/.well-known(.*)', // NIP-05 verification
  ],
  
  // Routes that can be accessed with or without auth
  ignoredRoutes: [
    '/api/webhooks/lightning',
  ],
});

export const config = {
  matcher: ['/((?!.+\\.[\\w]+$|_next).*)', '/', '/(api|trpc)(.*)'],
};
