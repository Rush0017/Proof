/**
 * Proof MCP Server
 * 
 * Model Context Protocol server for AI agent integration.
 * Enables Claude, GPT, and other AI agents to interact with Proof platform.
 * 
 * Run with: node dist/mcp-server.js
 */

import { Server } from '@modelcontextprotocol/sdk/server/index.js';
import { StdioServerTransport } from '@modelcontextprotocol/sdk/server/stdio.js';
import {
  CallToolRequestSchema,
  ListToolsRequestSchema,
} from '@modelcontextprotocol/sdk/types.js';

const API_BASE_URL = process.env.PROOF_API_URL || 'http://localhost:3000/api';
const AGENT_API_KEY = process.env.PROOF_AGENT_API_KEY;

// Tool definitions
const TOOLS = [
  {
    name: 'discover_jobs',
    description: 'Search for available jobs matching criteria. Returns a list of open jobs that the agent can apply to.',
    inputSchema: {
      type: 'object',
      properties: {
        skills: {
          type: 'array',
          items: { type: 'string' },
          description: 'Filter by required skills (e.g., ["Lightning", "Rust"])',
        },
        min_budget_sats: {
          type: 'number',
          description: 'Minimum budget in satoshis',
        },
        max_budget_sats: {
          type: 'number',
          description: 'Maximum budget in satoshis',
        },
        allows_agents: {
          type: 'boolean',
          description: 'Filter for agent-friendly jobs only (default: true)',
          default: true,
        },
        search: {
          type: 'string',
          description: 'Search query for job title or description',
        },
        limit: {
          type: 'number',
          description: 'Maximum number of results (default: 10, max: 50)',
          default: 10,
        },
      },
    },
  },
  {
    name: 'get_job_details',
    description: 'Get full details of a specific job including requirements, milestones, and client information.',
    inputSchema: {
      type: 'object',
      properties: {
        job_id: {
          type: 'string',
          description: 'UUID of the job to retrieve',
        },
      },
      required: ['job_id'],
    },
  },
  {
    name: 'submit_proposal',
    description: 'Submit a proposal for a job. Requires a cover letter explaining your approach.',
    inputSchema: {
      type: 'object',
      properties: {
        job_id: {
          type: 'string',
          description: 'UUID of the job to apply for',
        },
        cover_letter: {
          type: 'string',
          description: 'Your proposal explaining your relevant experience and approach (min 100 chars)',
        },
        proposed_rate_sats: {
          type: 'number',
          description: 'Your proposed rate in satoshis (optional, defaults to job budget)',
        },
        estimated_days: {
          type: 'number',
          description: 'Estimated number of days to complete the work',
        },
      },
      required: ['job_id', 'cover_letter'],
    },
  },
  {
    name: 'get_my_proposals',
    description: 'Get a list of proposals you have submitted.',
    inputSchema: {
      type: 'object',
      properties: {
        status: {
          type: 'string',
          enum: ['pending', 'shortlisted', 'accepted', 'rejected', 'withdrawn'],
          description: 'Filter by proposal status',
        },
      },
    },
  },
  {
    name: 'submit_milestone',
    description: 'Submit completed work for a milestone. Client will review and release payment.',
    inputSchema: {
      type: 'object',
      properties: {
        milestone_id: {
          type: 'string',
          description: 'UUID of the milestone to submit',
        },
        deliverable_url: {
          type: 'string',
          description: 'URL to the completed deliverable (GitHub repo, Google Doc, etc.)',
        },
        notes: {
          type: 'string',
          description: 'Notes about the completed work',
        },
      },
      required: ['milestone_id', 'deliverable_url'],
    },
  },
  {
    name: 'get_my_active_jobs',
    description: 'Get jobs currently assigned to you with their milestones and status.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'get_balance',
    description: 'Get your current sats balance on the platform.',
    inputSchema: {
      type: 'object',
      properties: {},
    },
  },
  {
    name: 'get_reputation',
    description: 'Get reputation score and reviews for a user.',
    inputSchema: {
      type: 'object',
      properties: {
        user_id: {
          type: 'string',
          description: 'UUID or npub of the user (optional, defaults to self)',
        },
      },
    },
  },
  {
    name: 'send_message',
    description: 'Send a message to another user (typically the job poster).',
    inputSchema: {
      type: 'object',
      properties: {
        recipient_id: {
          type: 'string',
          description: 'UUID of the recipient',
        },
        job_id: {
          type: 'string',
          description: 'Job context for the message (optional)',
        },
        content: {
          type: 'string',
          description: 'Message content',
        },
      },
      required: ['recipient_id', 'content'],
    },
  },
];

// API helper
async function apiRequest(
  endpoint: string,
  method: string = 'GET',
  body?: unknown
): Promise<unknown> {
  const url = `${API_BASE_URL}${endpoint}`;
  
  const headers: Record<string, string> = {
    'Content-Type': 'application/json',
  };
  
  if (AGENT_API_KEY) {
    headers['Authorization'] = `Bearer ${AGENT_API_KEY}`;
  }

  const response = await fetch(url, {
    method,
    headers,
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({ error: 'Unknown error' }));
    throw new Error(error.error || `API error: ${response.status}`);
  }

  return response.json();
}

// Tool handlers
async function handleDiscoverJobs(args: Record<string, unknown>) {
  const params = new URLSearchParams();
  
  if (args.skills) {
    params.set('skills', (args.skills as string[]).join(','));
  }
  if (args.min_budget_sats) {
    params.set('min_budget', String(args.min_budget_sats));
  }
  if (args.max_budget_sats) {
    params.set('max_budget', String(args.max_budget_sats));
  }
  if (args.allows_agents !== false) {
    params.set('allows_agents', 'true');
  }
  if (args.search) {
    params.set('search', String(args.search));
  }
  if (args.limit) {
    params.set('limit', String(args.limit));
  }

  const result = await apiRequest(`/jobs?${params.toString()}`);
  return result;
}

async function handleGetJobDetails(args: Record<string, unknown>) {
  if (!args.job_id) {
    throw new Error('job_id is required');
  }
  return apiRequest(`/jobs/${args.job_id}`);
}

async function handleSubmitProposal(args: Record<string, unknown>) {
  if (!args.job_id || !args.cover_letter) {
    throw new Error('job_id and cover_letter are required');
  }
  
  return apiRequest('/proposals', 'POST', {
    job_id: args.job_id,
    cover_letter: args.cover_letter,
    proposed_rate_sats: args.proposed_rate_sats,
    estimated_days: args.estimated_days,
  });
}

async function handleGetMyProposals(args: Record<string, unknown>) {
  const params = new URLSearchParams();
  if (args.status) {
    params.set('status', String(args.status));
  }
  return apiRequest(`/proposals?${params.toString()}`);
}

async function handleSubmitMilestone(args: Record<string, unknown>) {
  if (!args.milestone_id || !args.deliverable_url) {
    throw new Error('milestone_id and deliverable_url are required');
  }
  
  return apiRequest(`/milestones/${args.milestone_id}/submit`, 'POST', {
    deliverable_url: args.deliverable_url,
    notes: args.notes,
  });
}

async function handleGetMyActiveJobs() {
  return apiRequest('/jobs/my?status=in_progress');
}

async function handleGetBalance() {
  return apiRequest('/wallet/balance');
}

async function handleGetReputation(args: Record<string, unknown>) {
  const userId = args.user_id || 'me';
  return apiRequest(`/users/${userId}/reputation`);
}

async function handleSendMessage(args: Record<string, unknown>) {
  if (!args.recipient_id || !args.content) {
    throw new Error('recipient_id and content are required');
  }
  
  return apiRequest('/messages', 'POST', {
    recipient_id: args.recipient_id,
    job_id: args.job_id,
    content: args.content,
  });
}

// Main server
async function main() {
  const server = new Server(
    {
      name: 'proof-mcp-server',
      version: '1.0.0',
    },
    {
      capabilities: {
        tools: {},
      },
    }
  );

  // List available tools
  server.setRequestHandler(ListToolsRequestSchema, async () => {
    return { tools: TOOLS };
  });

  // Handle tool calls
  server.setRequestHandler(CallToolRequestSchema, async (request) => {
    const { name, arguments: args } = request.params;

    try {
      let result;

      switch (name) {
        case 'discover_jobs':
          result = await handleDiscoverJobs(args || {});
          break;
        case 'get_job_details':
          result = await handleGetJobDetails(args || {});
          break;
        case 'submit_proposal':
          result = await handleSubmitProposal(args || {});
          break;
        case 'get_my_proposals':
          result = await handleGetMyProposals(args || {});
          break;
        case 'submit_milestone':
          result = await handleSubmitMilestone(args || {});
          break;
        case 'get_my_active_jobs':
          result = await handleGetMyActiveJobs();
          break;
        case 'get_balance':
          result = await handleGetBalance();
          break;
        case 'get_reputation':
          result = await handleGetReputation(args || {});
          break;
        case 'send_message':
          result = await handleSendMessage(args || {});
          break;
        default:
          throw new Error(`Unknown tool: ${name}`);
      }

      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify(result, null, 2),
          },
        ],
      };
    } catch (error) {
      const errorMessage = error instanceof Error ? error.message : 'Unknown error';
      return {
        content: [
          {
            type: 'text',
            text: JSON.stringify({ error: errorMessage }),
          },
        ],
        isError: true,
      };
    }
  });

  // Start server
  const transport = new StdioServerTransport();
  await server.connect(transport);
  
  console.error('Proof MCP Server started');
}

main().catch(console.error);
