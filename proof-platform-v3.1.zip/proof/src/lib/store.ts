import { create } from 'zustand';
import { persist } from 'zustand/middleware';
import type { User, Job, Notification } from '@/lib/supabase';

// User store
interface UserState {
  user: User | null;
  setUser: (user: User | null) => void;
  updateUser: (updates: Partial<User>) => void;
}

export const useUserStore = create<UserState>()(
  persist(
    (set) => ({
      user: null,
      setUser: (user) => set({ user }),
      updateUser: (updates) =>
        set((state) => ({
          user: state.user ? { ...state.user, ...updates } : null,
        })),
    }),
    {
      name: 'proof-user',
    }
  )
);

// Wallet store
interface WalletState {
  balance: number;
  isLoading: boolean;
  lastUpdated: Date | null;
  setBalance: (balance: number) => void;
  setLoading: (isLoading: boolean) => void;
  refreshBalance: () => Promise<void>;
}

export const useWalletStore = create<WalletState>((set, get) => ({
  balance: 0,
  isLoading: false,
  lastUpdated: null,
  setBalance: (balance) => set({ balance, lastUpdated: new Date() }),
  setLoading: (isLoading) => set({ isLoading }),
  refreshBalance: async () => {
    set({ isLoading: true });
    try {
      const response = await fetch('/api/wallet/balance');
      const data = await response.json();
      set({ balance: data.balance, lastUpdated: new Date() });
    } catch (error) {
      console.error('Failed to refresh balance:', error);
    } finally {
      set({ isLoading: false });
    }
  },
}));

// Notifications store
interface NotificationState {
  notifications: Notification[];
  unreadCount: number;
  setNotifications: (notifications: Notification[]) => void;
  addNotification: (notification: Notification) => void;
  markAsRead: (id: string) => void;
  markAllAsRead: () => void;
}

export const useNotificationStore = create<NotificationState>((set, get) => ({
  notifications: [],
  unreadCount: 0,
  setNotifications: (notifications) =>
    set({
      notifications,
      unreadCount: notifications.filter((n) => !n.read_at).length,
    }),
  addNotification: (notification) =>
    set((state) => ({
      notifications: [notification, ...state.notifications],
      unreadCount: state.unreadCount + (notification.read_at ? 0 : 1),
    })),
  markAsRead: (id) =>
    set((state) => ({
      notifications: state.notifications.map((n) =>
        n.id === id ? { ...n, read_at: new Date().toISOString() } : n
      ),
      unreadCount: Math.max(0, state.unreadCount - 1),
    })),
  markAllAsRead: () =>
    set((state) => ({
      notifications: state.notifications.map((n) => ({
        ...n,
        read_at: n.read_at || new Date().toISOString(),
      })),
      unreadCount: 0,
    })),
}));

// UI store for modals, sidebars, etc.
interface UIState {
  isSidebarOpen: boolean;
  isSearchOpen: boolean;
  isWalletModalOpen: boolean;
  activeModal: string | null;
  toggleSidebar: () => void;
  toggleSearch: () => void;
  toggleWalletModal: () => void;
  openModal: (modal: string) => void;
  closeModal: () => void;
}

export const useUIStore = create<UIState>((set) => ({
  isSidebarOpen: true,
  isSearchOpen: false,
  isWalletModalOpen: false,
  activeModal: null,
  toggleSidebar: () => set((state) => ({ isSidebarOpen: !state.isSidebarOpen })),
  toggleSearch: () => set((state) => ({ isSearchOpen: !state.isSearchOpen })),
  toggleWalletModal: () =>
    set((state) => ({ isWalletModalOpen: !state.isWalletModalOpen })),
  openModal: (modal) => set({ activeModal: modal }),
  closeModal: () => set({ activeModal: null }),
}));

// Job draft store (for multi-step form)
interface JobDraftState {
  draft: Partial<Job> | null;
  setDraft: (draft: Partial<Job> | null) => void;
  updateDraft: (updates: Partial<Job>) => void;
  clearDraft: () => void;
}

export const useJobDraftStore = create<JobDraftState>()(
  persist(
    (set) => ({
      draft: null,
      setDraft: (draft) => set({ draft }),
      updateDraft: (updates) =>
        set((state) => ({
          draft: state.draft ? { ...state.draft, ...updates } : updates,
        })),
      clearDraft: () => set({ draft: null }),
    }),
    {
      name: 'proof-job-draft',
    }
  )
);
