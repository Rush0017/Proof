/**
 * Nostr Integration
 * 
 * Handles Nostr protocol interactions:
 * - Publishing job listings to Nostr (NIP-99 classifieds)
 * - Publishing reputation events (NIP-58 badges)
 * - NIP-05 verification
 * - Portable identity via npub
 */

import NDK, { 
  NDKEvent, 
  NDKPrivateKeySigner,
  NDKRelaySet,
  NDKUser
} from '@nostr-dev-kit/ndk';
import { nip19 } from 'nostr-tools';

// Initialize NDK
const RELAY_URLS = (process.env.NOSTR_RELAYS || 'wss://relay.damus.io,wss://nos.lol').split(',');

let ndk: NDK | null = null;
let signer: NDKPrivateKeySigner | null = null;

async function getNDK(): Promise<NDK> {
  if (ndk) return ndk;

  ndk = new NDK({
    explicitRelayUrls: RELAY_URLS,
  });

  // Add signer if platform key is configured
  if (process.env.NOSTR_PRIVATE_KEY) {
    const nsec = process.env.NOSTR_PRIVATE_KEY;
    const decoded = nip19.decode(nsec);
    if (decoded.type === 'nsec') {
      signer = new NDKPrivateKeySigner(decoded.data as string);
      ndk.signer = signer;
    }
  }

  await ndk.connect();
  return ndk;
}

// Event kinds
const KIND_JOB_LISTING = 30402; // NIP-99 classifieds
const KIND_BADGE_DEFINITION = 30009; // NIP-58 badge definition
const KIND_BADGE_AWARD = 8; // NIP-58 badge award
const KIND_PROFILE_BADGES = 30008; // NIP-58 profile badges

/**
 * Publish a job listing to Nostr
 */
export async function publishJobToNostr(job: {
  id: string;
  title: string;
  description: string;
  budget_sats: number;
  required_skills: string[];
  location_requirement: string;
  allows_agents: boolean;
  poster_npub?: string;
}): Promise<string | null> {
  try {
    const ndkInstance = await getNDK();

    const event = new NDKEvent(ndkInstance);
    event.kind = KIND_JOB_LISTING;
    event.content = job.description;
    
    event.tags = [
      ['d', job.id], // Unique identifier for replaceable event
      ['title', job.title],
      ['published_at', Math.floor(Date.now() / 1000).toString()],
      ['location', job.location_requirement],
      ['price', job.budget_sats.toString(), 'SATS'],
      ['t', 'job'], // Generic tag
      ['t', 'bitcoin'], // Bitcoin jobs
      ...job.required_skills.map(skill => ['t', skill.toLowerCase()]),
    ];

    if (job.allows_agents) {
      event.tags.push(['t', 'agent-friendly']);
    }

    if (job.poster_npub) {
      event.tags.push(['p', job.poster_npub]); // Reference to poster
    }

    // Add link back to Proof
    event.tags.push(['r', `${process.env.NEXT_PUBLIC_APP_URL}/jobs/${job.id}`]);

    await event.sign();
    await event.publish();

    return event.id;
  } catch (error) {
    console.error('Error publishing job to Nostr:', error);
    return null;
  }
}

/**
 * Create a badge definition for platform achievements
 */
export async function createBadgeDefinition(badge: {
  id: string;
  name: string;
  description: string;
  image_url?: string;
}): Promise<string | null> {
  try {
    const ndkInstance = await getNDK();

    const event = new NDKEvent(ndkInstance);
    event.kind = KIND_BADGE_DEFINITION;
    event.content = '';
    
    event.tags = [
      ['d', badge.id],
      ['name', badge.name],
      ['description', badge.description],
    ];

    if (badge.image_url) {
      event.tags.push(['image', badge.image_url]);
    }

    await event.sign();
    await event.publish();

    return event.id;
  } catch (error) {
    console.error('Error creating badge definition:', error);
    return null;
  }
}

/**
 * Award a badge to a user
 */
export async function awardBadge(
  badgeId: string,
  recipientPubkey: string,
  reason?: string
): Promise<string | null> {
  try {
    const ndkInstance = await getNDK();

    // Get platform pubkey
    const platformPubkey = process.env.NOSTR_PUBLIC_KEY;
    if (!platformPubkey) {
      throw new Error('Platform Nostr key not configured');
    }

    const decoded = nip19.decode(platformPubkey);
    const pubkeyHex = decoded.type === 'npub' ? decoded.data : platformPubkey;

    const event = new NDKEvent(ndkInstance);
    event.kind = KIND_BADGE_AWARD;
    event.content = reason || '';
    
    event.tags = [
      ['a', `${KIND_BADGE_DEFINITION}:${pubkeyHex}:${badgeId}`],
      ['p', recipientPubkey],
    ];

    await event.sign();
    await event.publish();

    return event.id;
  } catch (error) {
    console.error('Error awarding badge:', error);
    return null;
  }
}

/**
 * Publish a reputation event (job completion, review, etc.)
 */
export async function publishReputationEvent(event: {
  subject_pubkey: string;
  event_type: 'job_completed' | 'review' | 'payment_received';
  job_id?: string;
  rating?: number;
  review_text?: string;
  amount_sats?: number;
}): Promise<string | null> {
  try {
    const ndkInstance = await getNDK();

    const nostrEvent = new NDKEvent(ndkInstance);
    nostrEvent.kind = 1; // Regular note - could use custom kind
    
    let content = '';
    switch (event.event_type) {
      case 'job_completed':
        content = `✅ Completed a job on Proof${event.amount_sats ? ` and earned ${event.amount_sats.toLocaleString()} sats` : ''}`;
        break;
      case 'review':
        content = `⭐ ${event.rating}/5 - ${event.review_text || 'Great work!'}`;
        break;
      case 'payment_received':
        content = `⚡ Received ${event.amount_sats?.toLocaleString()} sats on Proof`;
        break;
    }

    nostrEvent.content = content;
    nostrEvent.tags = [
      ['p', event.subject_pubkey],
      ['t', 'proof'],
      ['t', 'bitcoin-jobs'],
    ];

    if (event.job_id) {
      nostrEvent.tags.push(['r', `${process.env.NEXT_PUBLIC_APP_URL}/jobs/${event.job_id}`]);
    }

    await nostrEvent.sign();
    await nostrEvent.publish();

    return nostrEvent.id;
  } catch (error) {
    console.error('Error publishing reputation event:', error);
    return null;
  }
}

/**
 * Verify NIP-05 identifier
 */
export async function verifyNip05(identifier: string): Promise<{
  valid: boolean;
  pubkey?: string;
  relays?: string[];
}> {
  try {
    const [name, domain] = identifier.split('@');
    if (!name || !domain) {
      return { valid: false };
    }

    const url = `https://${domain}/.well-known/nostr.json?name=${name}`;
    const response = await fetch(url);
    
    if (!response.ok) {
      return { valid: false };
    }

    const data = await response.json();
    const pubkey = data.names?.[name];

    if (!pubkey) {
      return { valid: false };
    }

    return {
      valid: true,
      pubkey,
      relays: data.relays?.[pubkey],
    };
  } catch (error) {
    console.error('NIP-05 verification error:', error);
    return { valid: false };
  }
}

/**
 * Get user profile from Nostr
 */
export async function getNostrProfile(pubkey: string): Promise<{
  name?: string;
  about?: string;
  picture?: string;
  nip05?: string;
  lud16?: string; // Lightning address
} | null> {
  try {
    const ndkInstance = await getNDK();
    const user = ndkInstance.getUser({ pubkey });
    await user.fetchProfile();

    return {
      name: user.profile?.name,
      about: user.profile?.about,
      picture: user.profile?.image,
      nip05: user.profile?.nip05,
      lud16: user.profile?.lud16,
    };
  } catch (error) {
    console.error('Error fetching Nostr profile:', error);
    return null;
  }
}

/**
 * Search for jobs on Nostr
 */
export async function searchNostrJobs(query: {
  skills?: string[];
  limit?: number;
}): Promise<NDKEvent[]> {
  try {
    const ndkInstance = await getNDK();
    
    const filter: Record<string, unknown> = {
      kinds: [KIND_JOB_LISTING],
      limit: query.limit || 50,
    };

    if (query.skills && query.skills.length > 0) {
      filter['#t'] = query.skills.map(s => s.toLowerCase());
    }

    const events = await ndkInstance.fetchEvents(filter);
    return Array.from(events);
  } catch (error) {
    console.error('Error searching Nostr jobs:', error);
    return [];
  }
}

// Badge definitions for Proof platform
export const PROOF_BADGES = {
  FIRST_JOB: {
    id: 'proof-first-job',
    name: 'First Job',
    description: 'Completed your first job on Proof',
  },
  TRUSTED_WORKER: {
    id: 'proof-trusted-worker',
    name: 'Trusted Worker',
    description: 'Completed 10+ jobs with 4.5+ rating',
  },
  LIGHTNING_FAST: {
    id: 'proof-lightning-fast',
    name: 'Lightning Fast',
    description: 'Completed a job ahead of schedule',
  },
  BITCOIN_BUILDER: {
    id: 'proof-bitcoin-builder',
    name: 'Bitcoin Builder',
    description: 'Contributed to Bitcoin/Lightning ecosystem projects',
  },
  TOP_EARNER: {
    id: 'proof-top-earner',
    name: 'Top Earner',
    description: 'Earned 10M+ sats on Proof',
  },
};
