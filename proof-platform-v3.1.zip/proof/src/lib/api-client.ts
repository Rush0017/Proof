// src/lib/api-client.ts
// API client that switches between real and mock based on NEXT_PUBLIC_MOCK_MODE

import * as mockData from './mock-data';

const IS_MOCK = process.env.NEXT_PUBLIC_MOCK_MODE === 'true';

// Simulate network delay
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

export interface ApiResponse<T> {
  data: T | null;
  error: string | null;
}

// Jobs
export async function getJobs(filters?: { 
  status?: string; 
  skills?: string[]; 
  allows_agents?: boolean;
  search?: string;
}): Promise<ApiResponse<typeof mockData.MOCK_JOBS>> {
  if (IS_MOCK) {
    await delay(300);
    return { data: mockData.getMockJobs(filters), error: null };
  }
  
  const params = new URLSearchParams();
  if (filters?.status) params.set('status', filters.status);
  if (filters?.skills?.length) params.set('skills', filters.skills.join(','));
  if (filters?.allows_agents !== undefined) params.set('allows_agents', String(filters.allows_agents));
  if (filters?.search) params.set('search', filters.search);
  
  const res = await fetch(`/api/jobs?${params}`);
  if (!res.ok) return { data: null, error: 'Failed to fetch jobs' };
  return { data: await res.json(), error: null };
}

export async function getJob(id: string): Promise<ApiResponse<typeof mockData.MOCK_JOBS[0]>> {
  if (IS_MOCK) {
    await delay(200);
    const job = mockData.getMockJob(id);
    return job ? { data: job, error: null } : { data: null, error: 'Job not found' };
  }
  
  const res = await fetch(`/api/jobs/${id}`);
  if (!res.ok) return { data: null, error: 'Failed to fetch job' };
  return { data: await res.json(), error: null };
}

export async function createJob(data: {
  title: string;
  description: string;
  budget_sats: number;
  required_skills: string[];
  allows_agents: boolean;
  payment_type: 'fixed' | 'milestone' | 'hourly';
  deadline?: string;
}): Promise<ApiResponse<{ id: string }>> {
  if (IS_MOCK) {
    await delay(500);
    return { data: { id: `job-${Date.now()}` }, error: null };
  }
  
  const res = await fetch('/api/jobs', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) return { data: null, error: 'Failed to create job' };
  return { data: await res.json(), error: null };
}

// Proposals
export async function getProposals(jobId?: string): Promise<ApiResponse<typeof mockData.MOCK_PROPOSALS>> {
  if (IS_MOCK) {
    await delay(250);
    return { data: mockData.getMockProposals(jobId), error: null };
  }
  
  const url = jobId ? `/api/jobs/${jobId}/proposals` : '/api/proposals';
  const res = await fetch(url);
  if (!res.ok) return { data: null, error: 'Failed to fetch proposals' };
  return { data: await res.json(), error: null };
}

export async function submitProposal(jobId: string, data: {
  cover_letter: string;
  proposed_rate_sats: number;
  estimated_duration_days: number;
}): Promise<ApiResponse<{ id: string }>> {
  if (IS_MOCK) {
    await delay(500);
    return { data: { id: `prop-${Date.now()}` }, error: null };
  }
  
  const res = await fetch(`/api/jobs/${jobId}/proposals`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) return { data: null, error: 'Failed to submit proposal' };
  return { data: await res.json(), error: null };
}

// Milestones
export async function getMilestones(jobId: string): Promise<ApiResponse<typeof mockData.MOCK_MILESTONES>> {
  if (IS_MOCK) {
    await delay(200);
    return { data: mockData.getMockMilestones(jobId), error: null };
  }
  
  const res = await fetch(`/api/jobs/${jobId}/milestones`);
  if (!res.ok) return { data: null, error: 'Failed to fetch milestones' };
  return { data: await res.json(), error: null };
}

// User
export async function getCurrentUser(): Promise<ApiResponse<typeof mockData.MOCK_USER>> {
  if (IS_MOCK) {
    await delay(150);
    return { data: mockData.getMockUser(), error: null };
  }
  
  const res = await fetch('/api/users/me');
  if (!res.ok) return { data: null, error: 'Failed to fetch user' };
  return { data: await res.json(), error: null };
}

export async function updateUser(data: Partial<typeof mockData.MOCK_USER>): Promise<ApiResponse<typeof mockData.MOCK_USER>> {
  if (IS_MOCK) {
    await delay(300);
    return { data: { ...mockData.MOCK_USER, ...data }, error: null };
  }
  
  const res = await fetch('/api/users/me', {
    method: 'PUT',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) return { data: null, error: 'Failed to update user' };
  return { data: await res.json(), error: null };
}

// Stats
export async function getStats(): Promise<ApiResponse<typeof mockData.MOCK_STATS>> {
  if (IS_MOCK) {
    await delay(200);
    return { data: mockData.getMockStats(), error: null };
  }
  
  const res = await fetch('/api/stats');
  if (!res.ok) return { data: null, error: 'Failed to fetch stats' };
  return { data: await res.json(), error: null };
}

// Skills
export async function getSkills(): Promise<ApiResponse<typeof mockData.MOCK_SKILLS>> {
  if (IS_MOCK) {
    await delay(150);
    return { data: mockData.getMockSkills(), error: null };
  }
  
  const res = await fetch('/api/skills');
  if (!res.ok) return { data: null, error: 'Failed to fetch skills' };
  return { data: await res.json(), error: null };
}

// Messages
export async function getMessages(threadId?: string): Promise<ApiResponse<typeof mockData.MOCK_MESSAGES>> {
  if (IS_MOCK) {
    await delay(200);
    return { data: mockData.getMockMessages(threadId), error: null };
  }
  
  const url = threadId ? `/api/messages/${threadId}` : '/api/messages';
  const res = await fetch(url);
  if (!res.ok) return { data: null, error: 'Failed to fetch messages' };
  return { data: await res.json(), error: null };
}

export async function sendMessage(threadId: string, content: string): Promise<ApiResponse<{ id: string }>> {
  if (IS_MOCK) {
    await delay(300);
    return { data: { id: `msg-${Date.now()}` }, error: null };
  }
  
  const res = await fetch(`/api/messages/${threadId}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ content }),
  });
  if (!res.ok) return { data: null, error: 'Failed to send message' };
  return { data: await res.json(), error: null };
}

// Lightning
export async function createInvoice(amount_sats: number, memo?: string): Promise<ApiResponse<{ 
  payment_request: string; 
  payment_hash: string;
}>> {
  if (IS_MOCK) {
    await delay(400);
    return { 
      data: { 
        payment_request: `lnbc${amount_sats}n1pjmock...`, 
        payment_hash: `hash_${Date.now()}` 
      }, 
      error: null 
    };
  }
  
  const res = await fetch('/api/lightning/invoice', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ amount_sats, memo }),
  });
  if (!res.ok) return { data: null, error: 'Failed to create invoice' };
  return { data: await res.json(), error: null };
}

export async function checkPayment(payment_hash: string): Promise<ApiResponse<{ paid: boolean }>> {
  if (IS_MOCK) {
    await delay(200);
    return { data: { paid: Math.random() > 0.5 }, error: null };
  }
  
  const res = await fetch(`/api/lightning/check/${payment_hash}`);
  if (!res.ok) return { data: null, error: 'Failed to check payment' };
  return { data: await res.json(), error: null };
}
