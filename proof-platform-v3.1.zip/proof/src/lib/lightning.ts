/**
 * Lightning Payments Service
 * 
 * Handles all Lightning Network payment operations:
 * - Invoice generation for escrow funding
 * - Payment verification
 * - Milestone payment releases
 * - Balance management
 * 
 * Supports LNbits for self-hosted or Alby for managed Lightning.
 */

import { createServerClient } from '@/lib/supabase';

// Types
export interface Invoice {
  payment_hash: string;
  payment_request: string;
  amount_sats: number;
  memo: string;
  expires_at: Date;
}

export interface PaymentResult {
  success: boolean;
  payment_hash?: string;
  preimage?: string;
  error?: string;
}

// Configuration
const LNBITS_URL = process.env.LNBITS_URL || 'https://legend.lnbits.com';
const LNBITS_ADMIN_KEY = process.env.LNBITS_ADMIN_KEY;
const LNBITS_INVOICE_KEY = process.env.LNBITS_INVOICE_KEY;

// LNbits API helpers
async function lnbitsRequest(
  endpoint: string,
  method: string = 'GET',
  body?: unknown,
  useAdminKey: boolean = false
) {
  const response = await fetch(`${LNBITS_URL}/api/v1${endpoint}`, {
    method,
    headers: {
      'Content-Type': 'application/json',
      'X-Api-Key': useAdminKey ? LNBITS_ADMIN_KEY! : LNBITS_INVOICE_KEY!,
    },
    body: body ? JSON.stringify(body) : undefined,
  });

  if (!response.ok) {
    const error = await response.json().catch(() => ({}));
    throw new Error(error.detail || `LNbits error: ${response.status}`);
  }

  return response.json();
}

/**
 * Create a Lightning invoice for escrow funding
 */
export async function createEscrowInvoice(
  jobId: string,
  amountSats: number,
  description: string
): Promise<Invoice> {
  const memo = `Proof Escrow: ${description} (Job: ${jobId})`;
  
  const result = await lnbitsRequest('/payments', 'POST', {
    out: false,
    amount: amountSats,
    memo,
    unit: 'sat',
    webhook: `${process.env.NEXT_PUBLIC_APP_URL}/api/webhooks/lightning`,
    extra: {
      type: 'escrow_fund',
      job_id: jobId,
    },
  });

  return {
    payment_hash: result.payment_hash,
    payment_request: result.payment_request,
    amount_sats: amountSats,
    memo,
    expires_at: new Date(Date.now() + 24 * 60 * 60 * 1000), // 24 hours
  };
}

/**
 * Check if a payment has been received
 */
export async function checkPayment(paymentHash: string): Promise<boolean> {
  try {
    const result = await lnbitsRequest(`/payments/${paymentHash}`);
    return result.paid === true;
  } catch {
    return false;
  }
}

/**
 * Pay a Lightning invoice (for milestone releases)
 */
export async function payInvoice(
  bolt11: string,
  maxFeeSats: number = 100
): Promise<PaymentResult> {
  try {
    const result = await lnbitsRequest('/payments', 'POST', {
      out: true,
      bolt11,
      fee_limit: maxFeeSats,
    }, true);

    return {
      success: true,
      payment_hash: result.payment_hash,
      preimage: result.checking_id,
    };
  } catch (error) {
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Payment failed',
    };
  }
}

/**
 * Get wallet balance
 */
export async function getWalletBalance(): Promise<number> {
  const result = await lnbitsRequest('/wallet');
  return Math.floor(result.balance / 1000); // msat to sat
}

/**
 * Fund job escrow after payment is received
 */
export async function fundEscrow(jobId: string, paymentHash: string): Promise<boolean> {
  const supabase = createServerClient();

  // Verify payment
  const paid = await checkPayment(paymentHash);
  if (!paid) {
    return false;
  }

  // Update job
  const { error } = await supabase
    .from('jobs')
    .update({
      escrow_funded: true,
      escrow_payment_hash: paymentHash,
      escrow_funded_at: new Date().toISOString(),
      status: 'open', // Move from draft to open
      published_at: new Date().toISOString(),
    })
    .eq('id', jobId)
    .eq('escrow_funded', false);

  if (error) {
    console.error('Error funding escrow:', error);
    return false;
  }

  // Record payment
  const { data: job } = await supabase
    .from('jobs')
    .select('poster_id, escrow_amount_sats')
    .eq('id', jobId)
    .single();

  if (job) {
    await supabase.from('payments').insert({
      from_user_id: job.poster_id,
      job_id: jobId,
      amount_sats: job.escrow_amount_sats,
      payment_type: 'escrow_fund',
      payment_hash: paymentHash,
      status: 'completed',
      paid_at: new Date().toISOString(),
    });
  }

  return true;
}

/**
 * Release milestone payment to worker
 */
export async function releaseMilestonePayment(
  milestoneId: string,
  approvedBy: string
): Promise<PaymentResult> {
  const supabase = createServerClient();

  // Get milestone details
  const { data: milestone, error: milestoneError } = await supabase
    .from('milestones')
    .select(`
      *,
      job:jobs(
        id,
        assigned_to,
        poster_id
      )
    `)
    .eq('id', milestoneId)
    .single();

  if (milestoneError || !milestone) {
    return { success: false, error: 'Milestone not found' };
  }

  if (milestone.payment_released) {
    return { success: false, error: 'Payment already released' };
  }

  if (milestone.status !== 'submitted') {
    return { success: false, error: 'Milestone not submitted for review' };
  }

  // Get worker's Lightning address
  const { data: worker } = await supabase
    .from('users')
    .select('lightning_address')
    .eq('id', milestone.job.assigned_to)
    .single();

  if (!worker?.lightning_address) {
    return { success: false, error: 'Worker has no Lightning address set' };
  }

  // Calculate payout (minus platform fee)
  const platformFee = Math.ceil(milestone.amount_sats * 0.025);
  const workerPayout = milestone.amount_sats - platformFee;

  // Create invoice via Lightning Address
  const lnurlPayUrl = `https://${worker.lightning_address.split('@')[1]}/.well-known/lnurlp/${worker.lightning_address.split('@')[0]}`;
  
  try {
    // Get LNURL-pay params
    const lnurlParams = await fetch(lnurlPayUrl).then(r => r.json());
    
    // Request invoice
    const callbackUrl = new URL(lnurlParams.callback);
    callbackUrl.searchParams.set('amount', String(workerPayout * 1000)); // msat
    
    const invoiceResponse = await fetch(callbackUrl.toString()).then(r => r.json());
    
    if (invoiceResponse.status === 'ERROR') {
      throw new Error(invoiceResponse.reason);
    }

    // Pay the invoice
    const paymentResult = await payInvoice(invoiceResponse.pr);
    
    if (!paymentResult.success) {
      return paymentResult;
    }

    // Update milestone
    await supabase
      .from('milestones')
      .update({
        status: 'approved',
        payment_released: true,
        payment_preimage: paymentResult.preimage,
        approved_at: new Date().toISOString(),
        approved_by: approvedBy,
      })
      .eq('id', milestoneId);

    // Record payment
    await supabase.from('payments').insert({
      from_user_id: milestone.job.poster_id,
      to_user_id: milestone.job.assigned_to,
      job_id: milestone.job.id,
      milestone_id: milestoneId,
      amount_sats: workerPayout,
      payment_type: 'milestone_release',
      payment_hash: paymentResult.payment_hash,
      payment_preimage: paymentResult.preimage,
      status: 'completed',
      paid_at: new Date().toISOString(),
    });

    // Record platform fee
    await supabase.from('payments').insert({
      from_user_id: milestone.job.poster_id,
      job_id: milestone.job.id,
      milestone_id: milestoneId,
      amount_sats: platformFee,
      payment_type: 'platform_fee',
      status: 'completed',
      paid_at: new Date().toISOString(),
    });

    // Create reputation event
    await supabase.from('reputation_events').insert({
      subject_id: milestone.job.assigned_to,
      author_id: milestone.job.poster_id,
      job_id: milestone.job.id,
      event_type: 'payment_received',
      amount_sats: workerPayout,
    });

    return paymentResult;
  } catch (error) {
    console.error('Payment error:', error);
    return {
      success: false,
      error: error instanceof Error ? error.message : 'Payment failed',
    };
  }
}

/**
 * Process incoming webhook from LNbits
 */
export async function processPaymentWebhook(data: {
  payment_hash: string;
  payment_request?: string;
  amount?: number;
  memo?: string;
  extra?: Record<string, unknown>;
}) {
  const { payment_hash, extra } = data;

  if (!extra?.type) {
    console.log('Webhook received but no type specified');
    return;
  }

  switch (extra.type) {
    case 'escrow_fund':
      if (extra.job_id) {
        await fundEscrow(extra.job_id as string, payment_hash);
      }
      break;
    default:
      console.log('Unknown payment type:', extra.type);
  }
}
