/**
 * L402 Authentication Middleware
 * 
 * Implements Lightning Network HTTP 402 protocol for API access.
 * Payment IS authentication - no API keys needed.
 * 
 * Flow:
 * 1. Client requests protected resource
 * 2. Server returns 402 with macaroon + invoice
 * 3. Client pays invoice, gets preimage
 * 4. Client presents macaroon:preimage as credentials
 * 5. Server verifies and grants access
 */

import { NextRequest, NextResponse } from 'next/server';
import { createEscrowInvoice, checkPayment } from './lightning';
import crypto from 'crypto';

// Pricing in sats
const ENDPOINT_PRICES: Record<string, number> = {
  '/api/l402/jobs': 10,           // List jobs
  '/api/l402/jobs/:id': 5,         // Get job details
  '/api/l402/proposals': 100,      // Submit proposal
  '/api/l402/search': 50,          // Semantic search
  '/api/l402/match': 500,          // AI matching
};

// Macaroon secret (should be in env)
const MACAROON_SECRET = process.env.MACAROON_SECRET || crypto.randomBytes(32).toString('hex');

interface Macaroon {
  identifier: string;
  payment_hash: string;
  caveats: string[];
  signature: string;
}

/**
 * Create a macaroon for a payment
 */
function createMacaroon(paymentHash: string, caveats: string[] = []): string {
  const identifier = crypto.randomBytes(16).toString('hex');
  
  const macaroon: Macaroon = {
    identifier,
    payment_hash: paymentHash,
    caveats,
    signature: '', // Will be computed
  };

  // Compute HMAC signature
  const data = JSON.stringify({ identifier, payment_hash: paymentHash, caveats });
  macaroon.signature = crypto
    .createHmac('sha256', MACAROON_SECRET)
    .update(data)
    .digest('hex');

  return Buffer.from(JSON.stringify(macaroon)).toString('base64');
}

/**
 * Verify a macaroon and preimage
 */
function verifyMacaroon(macaroonB64: string, preimage: string): { valid: boolean; paymentHash?: string } {
  try {
    const macaroon: Macaroon = JSON.parse(
      Buffer.from(macaroonB64, 'base64').toString()
    );

    // Verify signature
    const data = JSON.stringify({
      identifier: macaroon.identifier,
      payment_hash: macaroon.payment_hash,
      caveats: macaroon.caveats,
    });
    
    const expectedSig = crypto
      .createHmac('sha256', MACAROON_SECRET)
      .update(data)
      .digest('hex');

    if (macaroon.signature !== expectedSig) {
      return { valid: false };
    }

    // Verify preimage matches payment hash
    const computedHash = crypto
      .createHash('sha256')
      .update(Buffer.from(preimage, 'hex'))
      .digest('hex');

    if (computedHash !== macaroon.payment_hash) {
      return { valid: false };
    }

    // Check caveats (e.g., expiration)
    for (const caveat of macaroon.caveats) {
      if (caveat.startsWith('expires=')) {
        const expires = parseInt(caveat.split('=')[1]);
        if (Date.now() > expires) {
          return { valid: false };
        }
      }
    }

    return { valid: true, paymentHash: macaroon.payment_hash };
  } catch {
    return { valid: false };
  }
}

/**
 * Get price for an endpoint
 */
function getEndpointPrice(pathname: string): number {
  // Exact match
  if (ENDPOINT_PRICES[pathname]) {
    return ENDPOINT_PRICES[pathname];
  }

  // Pattern match (e.g., /api/l402/jobs/:id)
  for (const [pattern, price] of Object.entries(ENDPOINT_PRICES)) {
    const regex = new RegExp('^' + pattern.replace(/:id/g, '[^/]+') + '$');
    if (regex.test(pathname)) {
      return price;
    }
  }

  return 0; // Free endpoint
}

/**
 * L402 Middleware
 * 
 * Usage:
 * ```
 * export async function GET(request: NextRequest) {
 *   const l402Result = await checkL402(request);
 *   if (l402Result.response) return l402Result.response;
 *   
 *   // Handle authenticated request
 *   // l402Result.paymentHash is available for tracking
 * }
 * ```
 */
export async function checkL402(
  request: NextRequest
): Promise<{ valid: boolean; response?: NextResponse; paymentHash?: string }> {
  const pathname = request.nextUrl.pathname;
  const price = getEndpointPrice(pathname);

  // Free endpoint
  if (price === 0) {
    return { valid: true };
  }

  // Check for L402 authorization header
  const authHeader = request.headers.get('authorization');
  
  if (authHeader?.startsWith('L402 ')) {
    // Parse credentials
    const credentials = authHeader.slice(5);
    const [macaroon, preimage] = credentials.split(':');

    if (macaroon && preimage) {
      const result = verifyMacaroon(macaroon, preimage);
      
      if (result.valid) {
        return { valid: true, paymentHash: result.paymentHash };
      }
    }
  }

  // No valid credentials - return 402 with payment challenge
  const invoice = await createEscrowInvoice(
    crypto.randomBytes(16).toString('hex'), // Temporary ID
    price,
    `API Access: ${pathname}`
  );

  const macaroon = createMacaroon(invoice.payment_hash, [
    `expires=${Date.now() + 60 * 60 * 1000}`, // 1 hour expiry
    `endpoint=${pathname}`,
  ]);

  return {
    valid: false,
    response: NextResponse.json(
      {
        error: 'Payment Required',
        price_sats: price,
        invoice: invoice.payment_request,
        macaroon,
        expires_at: invoice.expires_at.toISOString(),
      },
      {
        status: 402,
        headers: {
          'WWW-Authenticate': `L402 macaroon="${macaroon}", invoice="${invoice.payment_request}"`,
        },
      }
    ),
  };
}

/**
 * Helper to create L402-protected API routes
 */
export function withL402(
  handler: (request: NextRequest, context: { paymentHash?: string }) => Promise<NextResponse>
) {
  return async (request: NextRequest) => {
    const l402Result = await checkL402(request);
    
    if (l402Result.response) {
      return l402Result.response;
    }

    return handler(request, { paymentHash: l402Result.paymentHash });
  };
}
