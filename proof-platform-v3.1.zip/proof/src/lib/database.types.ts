export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export interface Database {
  public: {
    Tables: {
      users: {
        Row: {
          id: string
          clerk_id: string | null
          npub: string | null
          is_agent: boolean
          lightning_address: string | null
          nwc_connection: string | null
          display_name: string
          username: string | null
          bio: string | null
          avatar_url: string | null
          website: string | null
          location: string | null
          timezone: string
          nip05_verified: boolean
          nip05_identifier: string | null
          email: string | null
          email_verified: boolean
          reputation_score: number
          jobs_completed: number
          jobs_posted: number
          total_earned_sats: number
          total_spent_sats: number
          allows_agent_applications: boolean
          public_profile: boolean
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          clerk_id?: string | null
          npub?: string | null
          is_agent?: boolean
          lightning_address?: string | null
          nwc_connection?: string | null
          display_name: string
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          website?: string | null
          location?: string | null
          timezone?: string
          nip05_verified?: boolean
          nip05_identifier?: string | null
          email?: string | null
          email_verified?: boolean
          reputation_score?: number
          jobs_completed?: number
          jobs_posted?: number
          total_earned_sats?: number
          total_spent_sats?: number
          allows_agent_applications?: boolean
          public_profile?: boolean
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          clerk_id?: string | null
          npub?: string | null
          is_agent?: boolean
          lightning_address?: string | null
          nwc_connection?: string | null
          display_name?: string
          username?: string | null
          bio?: string | null
          avatar_url?: string | null
          website?: string | null
          location?: string | null
          timezone?: string
          nip05_verified?: boolean
          nip05_identifier?: string | null
          email?: string | null
          email_verified?: boolean
          reputation_score?: number
          jobs_completed?: number
          jobs_posted?: number
          total_earned_sats?: number
          total_spent_sats?: number
          allows_agent_applications?: boolean
          public_profile?: boolean
          created_at?: string
          updated_at?: string
        }
      }
      user_skills: {
        Row: {
          id: string
          user_id: string
          skill_name: string
          skill_level: 'beginner' | 'intermediate' | 'advanced' | 'expert' | null
          years_experience: number | null
          verified: boolean
          verified_by: string | null
          verified_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          skill_name: string
          skill_level?: 'beginner' | 'intermediate' | 'advanced' | 'expert' | null
          years_experience?: number | null
          verified?: boolean
          verified_by?: string | null
          verified_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          skill_name?: string
          skill_level?: 'beginner' | 'intermediate' | 'advanced' | 'expert' | null
          years_experience?: number | null
          verified?: boolean
          verified_by?: string | null
          verified_at?: string | null
          created_at?: string
        }
      }
      jobs: {
        Row: {
          id: string
          poster_id: string
          title: string
          description: string
          requirements: string[]
          deliverables: string[]
          budget_sats: number
          payment_type: 'fixed' | 'hourly' | 'milestone'
          hourly_rate_sats: number | null
          status: 'draft' | 'open' | 'in_progress' | 'review' | 'completed' | 'cancelled' | 'disputed'
          assigned_to: string | null
          assigned_at: string | null
          required_skills: string[]
          preferred_skills: string[]
          experience_level: 'entry' | 'intermediate' | 'senior' | 'expert' | null
          location_requirement: string
          is_public: boolean
          allows_agents: boolean
          featured: boolean
          escrow_funded: boolean
          escrow_amount_sats: number
          escrow_invoice: string | null
          escrow_payment_hash: string | null
          escrow_funded_at: string | null
          nostr_event_id: string | null
          application_deadline: string | null
          completion_deadline: string | null
          published_at: string | null
          started_at: string | null
          completed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          poster_id: string
          title: string
          description: string
          requirements?: string[]
          deliverables?: string[]
          budget_sats: number
          payment_type?: 'fixed' | 'hourly' | 'milestone'
          hourly_rate_sats?: number | null
          status?: 'draft' | 'open' | 'in_progress' | 'review' | 'completed' | 'cancelled' | 'disputed'
          assigned_to?: string | null
          assigned_at?: string | null
          required_skills?: string[]
          preferred_skills?: string[]
          experience_level?: 'entry' | 'intermediate' | 'senior' | 'expert' | null
          location_requirement?: string
          is_public?: boolean
          allows_agents?: boolean
          featured?: boolean
          escrow_funded?: boolean
          escrow_amount_sats?: number
          escrow_invoice?: string | null
          escrow_payment_hash?: string | null
          escrow_funded_at?: string | null
          nostr_event_id?: string | null
          application_deadline?: string | null
          completion_deadline?: string | null
          published_at?: string | null
          started_at?: string | null
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          poster_id?: string
          title?: string
          description?: string
          requirements?: string[]
          deliverables?: string[]
          budget_sats?: number
          payment_type?: 'fixed' | 'hourly' | 'milestone'
          hourly_rate_sats?: number | null
          status?: 'draft' | 'open' | 'in_progress' | 'review' | 'completed' | 'cancelled' | 'disputed'
          assigned_to?: string | null
          assigned_at?: string | null
          required_skills?: string[]
          preferred_skills?: string[]
          experience_level?: 'entry' | 'intermediate' | 'senior' | 'expert' | null
          location_requirement?: string
          is_public?: boolean
          allows_agents?: boolean
          featured?: boolean
          escrow_funded?: boolean
          escrow_amount_sats?: number
          escrow_invoice?: string | null
          escrow_payment_hash?: string | null
          escrow_funded_at?: string | null
          nostr_event_id?: string | null
          application_deadline?: string | null
          completion_deadline?: string | null
          published_at?: string | null
          started_at?: string | null
          completed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      proposals: {
        Row: {
          id: string
          job_id: string
          proposer_id: string
          cover_letter: string
          proposed_rate_sats: number | null
          estimated_hours: number | null
          estimated_days: number | null
          status: 'pending' | 'shortlisted' | 'accepted' | 'rejected' | 'withdrawn'
          submitted_at: string
          reviewed_at: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          job_id: string
          proposer_id: string
          cover_letter: string
          proposed_rate_sats?: number | null
          estimated_hours?: number | null
          estimated_days?: number | null
          status?: 'pending' | 'shortlisted' | 'accepted' | 'rejected' | 'withdrawn'
          submitted_at?: string
          reviewed_at?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          job_id?: string
          proposer_id?: string
          cover_letter?: string
          proposed_rate_sats?: number | null
          estimated_hours?: number | null
          estimated_days?: number | null
          status?: 'pending' | 'shortlisted' | 'accepted' | 'rejected' | 'withdrawn'
          submitted_at?: string
          reviewed_at?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      milestones: {
        Row: {
          id: string
          job_id: string
          title: string
          description: string | null
          order_index: number
          amount_sats: number
          status: 'pending' | 'in_progress' | 'submitted' | 'revision_requested' | 'approved' | 'disputed' | 'cancelled'
          escrow_locked: boolean
          payment_released: boolean
          payment_hash: string | null
          payment_preimage: string | null
          deliverable_url: string | null
          deliverable_notes: string | null
          submitted_at: string | null
          reviewer_notes: string | null
          approved_at: string | null
          approved_by: string | null
          due_date: string | null
          created_at: string
          updated_at: string
        }
        Insert: {
          id?: string
          job_id: string
          title: string
          description?: string | null
          order_index?: number
          amount_sats: number
          status?: 'pending' | 'in_progress' | 'submitted' | 'revision_requested' | 'approved' | 'disputed' | 'cancelled'
          escrow_locked?: boolean
          payment_released?: boolean
          payment_hash?: string | null
          payment_preimage?: string | null
          deliverable_url?: string | null
          deliverable_notes?: string | null
          submitted_at?: string | null
          reviewer_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          due_date?: string | null
          created_at?: string
          updated_at?: string
        }
        Update: {
          id?: string
          job_id?: string
          title?: string
          description?: string | null
          order_index?: number
          amount_sats?: number
          status?: 'pending' | 'in_progress' | 'submitted' | 'revision_requested' | 'approved' | 'disputed' | 'cancelled'
          escrow_locked?: boolean
          payment_released?: boolean
          payment_hash?: string | null
          payment_preimage?: string | null
          deliverable_url?: string | null
          deliverable_notes?: string | null
          submitted_at?: string | null
          reviewer_notes?: string | null
          approved_at?: string | null
          approved_by?: string | null
          due_date?: string | null
          created_at?: string
          updated_at?: string
        }
      }
      messages: {
        Row: {
          id: string
          sender_id: string
          recipient_id: string
          job_id: string | null
          content: string
          is_encrypted: boolean
          read_at: string | null
          created_at: string
        }
        Insert: {
          id?: string
          sender_id: string
          recipient_id: string
          job_id?: string | null
          content: string
          is_encrypted?: boolean
          read_at?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          sender_id?: string
          recipient_id?: string
          job_id?: string | null
          content?: string
          is_encrypted?: boolean
          read_at?: string | null
          created_at?: string
        }
      }
      reputation_events: {
        Row: {
          id: string
          subject_id: string
          author_id: string
          job_id: string | null
          event_type: 'job_completed' | 'job_posted' | 'payment_sent' | 'payment_received' | 'review_given' | 'review_received' | 'endorsement' | 'badge_earned' | 'verification'
          rating: number | null
          review_text: string | null
          amount_sats: number | null
          nostr_event_id: string | null
          nostr_signature: string | null
          metadata: Json
          created_at: string
        }
        Insert: {
          id?: string
          subject_id: string
          author_id: string
          job_id?: string | null
          event_type: 'job_completed' | 'job_posted' | 'payment_sent' | 'payment_received' | 'review_given' | 'review_received' | 'endorsement' | 'badge_earned' | 'verification'
          rating?: number | null
          review_text?: string | null
          amount_sats?: number | null
          nostr_event_id?: string | null
          nostr_signature?: string | null
          metadata?: Json
          created_at?: string
        }
        Update: {
          id?: string
          subject_id?: string
          author_id?: string
          job_id?: string | null
          event_type?: 'job_completed' | 'job_posted' | 'payment_sent' | 'payment_received' | 'review_given' | 'review_received' | 'endorsement' | 'badge_earned' | 'verification'
          rating?: number | null
          review_text?: string | null
          amount_sats?: number | null
          nostr_event_id?: string | null
          nostr_signature?: string | null
          metadata?: Json
          created_at?: string
        }
      }
      payments: {
        Row: {
          id: string
          from_user_id: string | null
          to_user_id: string | null
          job_id: string | null
          milestone_id: string | null
          amount_sats: number
          payment_type: 'escrow_fund' | 'milestone_release' | 'job_completion' | 'tip' | 'referral_bonus' | 'platform_fee'
          invoice: string | null
          payment_hash: string | null
          payment_preimage: string | null
          status: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded'
          created_at: string
          paid_at: string | null
          metadata: Json
        }
        Insert: {
          id?: string
          from_user_id?: string | null
          to_user_id?: string | null
          job_id?: string | null
          milestone_id?: string | null
          amount_sats: number
          payment_type: 'escrow_fund' | 'milestone_release' | 'job_completion' | 'tip' | 'referral_bonus' | 'platform_fee'
          invoice?: string | null
          payment_hash?: string | null
          payment_preimage?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded'
          created_at?: string
          paid_at?: string | null
          metadata?: Json
        }
        Update: {
          id?: string
          from_user_id?: string | null
          to_user_id?: string | null
          job_id?: string | null
          milestone_id?: string | null
          amount_sats?: number
          payment_type?: 'escrow_fund' | 'milestone_release' | 'job_completion' | 'tip' | 'referral_bonus' | 'platform_fee'
          invoice?: string | null
          payment_hash?: string | null
          payment_preimage?: string | null
          status?: 'pending' | 'processing' | 'completed' | 'failed' | 'refunded'
          created_at?: string
          paid_at?: string | null
          metadata?: Json
        }
      }
      notifications: {
        Row: {
          id: string
          user_id: string
          type: string
          title: string
          body: string | null
          job_id: string | null
          proposal_id: string | null
          message_id: string | null
          read_at: string | null
          action_url: string | null
          created_at: string
        }
        Insert: {
          id?: string
          user_id: string
          type: string
          title: string
          body?: string | null
          job_id?: string | null
          proposal_id?: string | null
          message_id?: string | null
          read_at?: string | null
          action_url?: string | null
          created_at?: string
        }
        Update: {
          id?: string
          user_id?: string
          type?: string
          title?: string
          body?: string | null
          job_id?: string | null
          proposal_id?: string | null
          message_id?: string | null
          read_at?: string | null
          action_url?: string | null
          created_at?: string
        }
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      search_jobs_semantic: {
        Args: {
          query_embedding: number[]
          match_threshold?: number
          match_count?: number
        }
        Returns: {
          id: string
          title: string
          description: string
          budget_sats: number
          similarity: number
        }[]
      }
    }
    Enums: {
      [_ in never]: never
    }
  }
}
