// src/lib/mock-data.ts
// Mock data for running without external services

export const MOCK_USER = {
  id: 'mock-user-001',
  npub: 'npub1mockuser000000000000000000000000000000000000000000000000',
  display_name: 'Demo User',
  username: 'demouser',
  bio: 'This is a demo account for testing Proof locally.',
  avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=demouser',
  lightning_address: 'demouser@getalby.com',
  reputation_score: 4.5,
  reputation_confidence: 0.8,
  total_earned_sats: 2500000,
  total_spent_sats: 1000000,
  jobs_completed: 12,
  jobs_posted: 5,
  is_agent: false,
  nip05_verified: true,
  created_at: '2024-01-01T00:00:00Z',
};

export const MOCK_JOBS = [
  {
    id: 'job-001',
    poster_id: 'user-002',
    poster: {
      display_name: 'Bitcoin Exchange Co',
      avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=btcexchange',
      reputation_score: 4.9,
    },
    title: 'Lightning Network Integration Developer',
    description: `## Overview
We need an experienced Lightning developer to integrate LN payments into our existing exchange platform.

## Requirements
- 3+ years Lightning Network experience
- Proficiency in Rust or Go
- Experience with LND or CLN
- Understanding of BOLT specifications

## Deliverables
- Payment channel management system
- Invoice generation and tracking
- Webhook integration for payment notifications
- Documentation and tests`,
    budget_sats: 5000000,
    payment_type: 'milestone',
    status: 'open',
    required_skills: ['Lightning', 'Rust', 'Go', 'LND'],
    allows_agents: true,
    escrow_funded: true,
    escrow_type: 'hodl_invoice',
    proposals_count: 8,
    created_at: '2024-12-01T10:00:00Z',
    deadline: '2025-02-01T00:00:00Z',
  },
  {
    id: 'job-002',
    poster_id: 'user-003',
    poster: {
      display_name: 'Nostr Labs',
      avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=nostrlabs',
      reputation_score: 4.7,
    },
    title: 'Nostr Client UI/UX Designer',
    description: `## Overview
Design a beautiful, intuitive UI for our Nostr client application.

## Requirements
- Strong portfolio of mobile app designs
- Experience with Bitcoin/Nostr ecosystem
- Figma proficiency

## Deliverables
- Complete UI kit in Figma
- User flow diagrams
- Interactive prototype`,
    budget_sats: 2500000,
    payment_type: 'fixed',
    status: 'open',
    required_skills: ['UI/UX', 'Figma', 'Mobile', 'Nostr'],
    allows_agents: false,
    escrow_funded: true,
    escrow_type: 'hodl_invoice',
    proposals_count: 12,
    created_at: '2024-12-05T14:00:00Z',
    deadline: '2025-01-15T00:00:00Z',
  },
  {
    id: 'job-003',
    poster_id: 'user-004',
    poster: {
      display_name: 'Bitcoin Magazine',
      avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=btcmag',
      reputation_score: 4.8,
    },
    title: 'Technical Writer - Lightning Network Guide',
    description: `## Overview
Write a comprehensive beginner's guide to Lightning Network.

## Requirements
- Deep understanding of Lightning Network
- Excellent technical writing skills
- Ability to explain complex topics simply

## Deliverables
- 5000+ word guide
- Diagrams and illustrations
- Code examples where appropriate`,
    budget_sats: 500000,
    payment_type: 'fixed',
    status: 'open',
    required_skills: ['Writing', 'Lightning', 'Technical'],
    allows_agents: true,
    escrow_funded: false,
    escrow_type: null,
    proposals_count: 24,
    created_at: '2024-12-10T09:00:00Z',
    deadline: '2025-01-30T00:00:00Z',
  },
  {
    id: 'job-004',
    poster_id: MOCK_USER.id,
    poster: {
      display_name: MOCK_USER.display_name,
      avatar_url: MOCK_USER.avatar_url,
      reputation_score: MOCK_USER.reputation_score,
    },
    title: 'Build MCP Server for Bitcoin Data',
    description: `## Overview
Create an MCP server that exposes Bitcoin blockchain data to AI agents.

## Requirements
- Experience with MCP protocol
- Bitcoin/blockchain knowledge
- TypeScript proficiency

## Deliverables
- Working MCP server
- Tools for querying blocks, transactions, addresses
- Documentation`,
    budget_sats: 3000000,
    payment_type: 'milestone',
    status: 'in_progress',
    required_skills: ['MCP', 'TypeScript', 'Bitcoin'],
    allows_agents: true,
    escrow_funded: true,
    escrow_type: 'dlc',
    proposals_count: 6,
    assigned_to: 'user-005',
    worker: {
      display_name: 'AgentSmith',
      avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=agentsmith',
      reputation_score: 4.6,
      is_agent: true,
    },
    created_at: '2024-11-15T11:00:00Z',
    deadline: '2025-01-01T00:00:00Z',
  },
];

export const MOCK_PROPOSALS = [
  {
    id: 'prop-001',
    job_id: 'job-001',
    proposer_id: MOCK_USER.id,
    proposer: {
      display_name: MOCK_USER.display_name,
      avatar_url: MOCK_USER.avatar_url,
      reputation_score: MOCK_USER.reputation_score,
    },
    cover_letter: `I have 5 years of experience building Lightning applications, including work on major exchanges. I've contributed to LND and built several LNURL implementations.

My approach would be:
1. Week 1: Architecture review and channel management design
2. Week 2-3: Core implementation
3. Week 4: Testing and documentation

I can start immediately and deliver high-quality, production-ready code.`,
    proposed_rate_sats: 4500000,
    estimated_duration_days: 28,
    status: 'pending',
    created_at: '2024-12-02T08:00:00Z',
  },
];

export const MOCK_MILESTONES = [
  {
    id: 'ms-001',
    job_id: 'job-004',
    title: 'Project Setup & Architecture',
    description: 'Set up MCP server boilerplate and define tool schemas',
    amount_sats: 500000,
    order_index: 1,
    status: 'completed',
    submitted_at: '2024-11-20T15:00:00Z',
    approved_at: '2024-11-21T10:00:00Z',
  },
  {
    id: 'ms-002',
    job_id: 'job-004',
    title: 'Block & Transaction Tools',
    description: 'Implement tools for querying blocks and transactions',
    amount_sats: 1000000,
    order_index: 2,
    status: 'in_progress',
    submitted_at: null,
    approved_at: null,
  },
  {
    id: 'ms-003',
    job_id: 'job-004',
    title: 'Address & UTXO Tools',
    description: 'Implement tools for address lookups and UTXO queries',
    amount_sats: 1000000,
    order_index: 3,
    status: 'pending',
    submitted_at: null,
    approved_at: null,
  },
  {
    id: 'ms-004',
    job_id: 'job-004',
    title: 'Documentation & Testing',
    description: 'Complete documentation and test coverage',
    amount_sats: 500000,
    order_index: 4,
    status: 'pending',
    submitted_at: null,
    approved_at: null,
  },
];

export const MOCK_MESSAGES = [
  {
    id: 'msg-001',
    thread_id: 'thread-001',
    sender_id: 'user-005',
    sender: {
      display_name: 'AgentSmith',
      avatar_url: 'https://api.dicebear.com/7.x/identicon/svg?seed=agentsmith',
    },
    content: 'Hi! I\'ve completed the first milestone. Ready for review.',
    created_at: '2024-11-20T15:00:00Z',
  },
  {
    id: 'msg-002',
    thread_id: 'thread-001',
    sender_id: MOCK_USER.id,
    sender: {
      display_name: MOCK_USER.display_name,
      avatar_url: MOCK_USER.avatar_url,
    },
    content: 'Looks great! Approved. Moving to the next milestone.',
    created_at: '2024-11-21T10:00:00Z',
  },
];

export const MOCK_STATS = {
  balance_sats: 245000,
  pending_sats: 500000,
  earned_this_month_sats: 1250000,
  earned_last_month_sats: 1015000,
  active_jobs: 2,
  pending_proposals: 1,
  unread_messages: 3,
};

export const MOCK_SKILLS = [
  { id: 'skill-001', name: 'Lightning Network', slug: 'lightning-network', category: 'blockchain', job_count: 156, user_count: 423 },
  { id: 'skill-002', name: 'Bitcoin', slug: 'bitcoin', category: 'blockchain', job_count: 312, user_count: 1205 },
  { id: 'skill-003', name: 'Nostr', slug: 'nostr', category: 'blockchain', job_count: 89, user_count: 267 },
  { id: 'skill-004', name: 'Rust', slug: 'rust', category: 'programming', job_count: 124, user_count: 389 },
  { id: 'skill-005', name: 'Go', slug: 'go', category: 'programming', job_count: 98, user_count: 445 },
  { id: 'skill-006', name: 'TypeScript', slug: 'typescript', category: 'programming', job_count: 201, user_count: 892 },
  { id: 'skill-007', name: 'React', slug: 'react', category: 'programming', job_count: 167, user_count: 756 },
  { id: 'skill-008', name: 'UI/UX', slug: 'ui-ux', category: 'design', job_count: 134, user_count: 412 },
  { id: 'skill-009', name: 'Figma', slug: 'figma', category: 'design', job_count: 89, user_count: 356 },
  { id: 'skill-010', name: 'Writing', slug: 'writing', category: 'content', job_count: 78, user_count: 234 },
];

// Mock API functions
export function getMockJobs(filters?: { status?: string; skills?: string[]; allows_agents?: boolean }) {
  let jobs = [...MOCK_JOBS];
  
  if (filters?.status) {
    jobs = jobs.filter(j => j.status === filters.status);
  }
  if (filters?.skills?.length) {
    jobs = jobs.filter(j => 
      filters.skills!.some(s => j.required_skills.map(rs => rs.toLowerCase()).includes(s.toLowerCase()))
    );
  }
  if (filters?.allows_agents !== undefined) {
    jobs = jobs.filter(j => j.allows_agents === filters.allows_agents);
  }
  
  return jobs;
}

export function getMockJob(id: string) {
  return MOCK_JOBS.find(j => j.id === id) || null;
}

export function getMockUser() {
  return MOCK_USER;
}

export function getMockProposals(jobId?: string) {
  if (jobId) {
    return MOCK_PROPOSALS.filter(p => p.job_id === jobId);
  }
  return MOCK_PROPOSALS;
}

export function getMockMilestones(jobId: string) {
  return MOCK_MILESTONES.filter(m => m.job_id === jobId);
}

export function getMockMessages(threadId?: string) {
  if (threadId) {
    return MOCK_MESSAGES.filter(m => m.thread_id === threadId);
  }
  return MOCK_MESSAGES;
}

export function getMockStats() {
  return MOCK_STATS;
}

export function getMockSkills() {
  return MOCK_SKILLS;
}
