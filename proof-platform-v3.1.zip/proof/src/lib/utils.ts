import { type ClassValue, clsx } from 'clsx';
import { twMerge } from 'tailwind-merge';

/**
 * Merge Tailwind CSS classes with clsx
 */
export function cn(...inputs: ClassValue[]) {
  return twMerge(clsx(inputs));
}

/**
 * Format sats with proper formatting
 */
export function formatSats(sats: number | bigint): string {
  const num = typeof sats === 'bigint' ? Number(sats) : sats;
  
  if (num >= 100_000_000) {
    // Show in BTC for amounts >= 1 BTC
    return `₿${(num / 100_000_000).toFixed(2)}`;
  }
  
  if (num >= 1_000_000) {
    // Show in millions for large amounts
    return `${(num / 1_000_000).toFixed(1)}M sats`;
  }
  
  if (num >= 1_000) {
    // Show in thousands
    return `${(num / 1_000).toFixed(1)}k sats`;
  }
  
  return `${num.toLocaleString()} sats`;
}

/**
 * Format sats to USD (approximate)
 */
export function satsToUsd(sats: number, btcPrice: number = 100000): string {
  const btc = sats / 100_000_000;
  const usd = btc * btcPrice;
  return new Intl.NumberFormat('en-US', {
    style: 'currency',
    currency: 'USD',
    minimumFractionDigits: usd < 1 ? 2 : 0,
    maximumFractionDigits: usd < 1 ? 2 : 0,
  }).format(usd);
}

/**
 * Parse sats from various input formats
 */
export function parseSats(input: string): number | null {
  // Remove common formatting
  const cleaned = input
    .replace(/,/g, '')
    .replace(/\s+/g, '')
    .replace(/sats?$/i, '')
    .trim();
  
  // Handle k/m suffixes
  const match = cleaned.match(/^(\d+(?:\.\d+)?)(k|m)?$/i);
  if (!match) return null;
  
  let value = parseFloat(match[1]);
  const suffix = match[2]?.toLowerCase();
  
  if (suffix === 'k') value *= 1_000;
  if (suffix === 'm') value *= 1_000_000;
  
  return Math.floor(value);
}

/**
 * Format relative time (e.g., "2 hours ago")
 */
export function formatRelativeTime(date: Date | string): string {
  const now = new Date();
  const then = typeof date === 'string' ? new Date(date) : date;
  const seconds = Math.floor((now.getTime() - then.getTime()) / 1000);
  
  const intervals = [
    { label: 'year', seconds: 31536000 },
    { label: 'month', seconds: 2592000 },
    { label: 'week', seconds: 604800 },
    { label: 'day', seconds: 86400 },
    { label: 'hour', seconds: 3600 },
    { label: 'minute', seconds: 60 },
  ];
  
  for (const interval of intervals) {
    const count = Math.floor(seconds / interval.seconds);
    if (count >= 1) {
      return `${count} ${interval.label}${count > 1 ? 's' : ''} ago`;
    }
  }
  
  return 'just now';
}

/**
 * Truncate npub for display
 */
export function truncateNpub(npub: string): string {
  if (npub.length <= 16) return npub;
  return `${npub.slice(0, 8)}...${npub.slice(-8)}`;
}

/**
 * Truncate Lightning address for display
 */
export function truncateLnAddress(address: string): string {
  const [user, domain] = address.split('@');
  if (user.length <= 8) return address;
  return `${user.slice(0, 6)}...@${domain}`;
}

/**
 * Generate initials from name
 */
export function getInitials(name: string): string {
  return name
    .split(' ')
    .map(word => word[0])
    .join('')
    .toUpperCase()
    .slice(0, 2);
}

/**
 * Validate Lightning address format
 */
export function isValidLightningAddress(address: string): boolean {
  return /^[a-zA-Z0-9._-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$/.test(address);
}

/**
 * Validate npub format
 */
export function isValidNpub(npub: string): boolean {
  return /^npub1[a-z0-9]{58}$/.test(npub);
}

/**
 * Generate referral code
 */
export function generateReferralCode(): string {
  const chars = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
  let code = '';
  for (let i = 0; i < 8; i++) {
    code += chars[Math.floor(Math.random() * chars.length)];
  }
  return code;
}

/**
 * Calculate platform fee (2.5%)
 */
export function calculatePlatformFee(amountSats: number): number {
  return Math.ceil(amountSats * 0.025);
}

/**
 * Calculate worker payout after platform fee
 */
export function calculateWorkerPayout(amountSats: number): number {
  return amountSats - calculatePlatformFee(amountSats);
}

/**
 * Debounce function
 */
export function debounce<T extends (...args: unknown[]) => unknown>(
  func: T,
  wait: number
): (...args: Parameters<T>) => void {
  let timeout: NodeJS.Timeout | null = null;
  
  return (...args: Parameters<T>) => {
    if (timeout) clearTimeout(timeout);
    timeout = setTimeout(() => func(...args), wait);
  };
}

/**
 * Sleep utility
 */
export function sleep(ms: number): Promise<void> {
  return new Promise(resolve => setTimeout(resolve, ms));
}

/**
 * Safe JSON parse
 */
export function safeJsonParse<T>(json: string, fallback: T): T {
  try {
    return JSON.parse(json) as T;
  } catch {
    return fallback;
  }
}

/**
 * Skill level to numeric value
 */
export function skillLevelToNumber(level: string): number {
  const levels: Record<string, number> = {
    beginner: 1,
    intermediate: 2,
    advanced: 3,
    expert: 4,
  };
  return levels[level] || 0;
}

/**
 * Experience level display text
 */
export function formatExperienceLevel(level: string): string {
  const labels: Record<string, string> = {
    entry: 'Entry Level',
    intermediate: 'Mid Level',
    senior: 'Senior',
    expert: 'Expert',
  };
  return labels[level] || level;
}

/**
 * Job status display text and color
 */
export function getJobStatusDisplay(status: string): { label: string; color: string } {
  const statuses: Record<string, { label: string; color: string }> = {
    draft: { label: 'Draft', color: 'gray' },
    open: { label: 'Open', color: 'green' },
    in_progress: { label: 'In Progress', color: 'blue' },
    review: { label: 'In Review', color: 'yellow' },
    completed: { label: 'Completed', color: 'emerald' },
    cancelled: { label: 'Cancelled', color: 'red' },
    disputed: { label: 'Disputed', color: 'orange' },
  };
  return statuses[status] || { label: status, color: 'gray' };
}

/**
 * Proposal status display
 */
export function getProposalStatusDisplay(status: string): { label: string; color: string } {
  const statuses: Record<string, { label: string; color: string }> = {
    pending: { label: 'Pending', color: 'yellow' },
    shortlisted: { label: 'Shortlisted', color: 'blue' },
    accepted: { label: 'Accepted', color: 'green' },
    rejected: { label: 'Rejected', color: 'red' },
    withdrawn: { label: 'Withdrawn', color: 'gray' },
  };
  return statuses[status] || { label: status, color: 'gray' };
}
