import { createClient } from '@supabase/supabase-js';
import type { Database } from './database.types';

const supabaseUrl = process.env.NEXT_PUBLIC_SUPABASE_URL!;
const supabaseAnonKey = process.env.NEXT_PUBLIC_SUPABASE_ANON_KEY!;

// Client-side Supabase client
export const supabase = createClient<Database>(supabaseUrl, supabaseAnonKey, {
  auth: {
    persistSession: true,
    autoRefreshToken: true,
  },
  realtime: {
    params: {
      eventsPerSecond: 10,
    },
  },
});

// Server-side Supabase client with service role
export function createServerClient() {
  const supabaseServiceKey = process.env.SUPABASE_SERVICE_ROLE_KEY!;
  return createClient<Database>(supabaseUrl, supabaseServiceKey, {
    auth: {
      persistSession: false,
      autoRefreshToken: false,
    },
  });
}

// Types for easier access
export type Tables = Database['public']['Tables'];
export type User = Tables['users']['Row'];
export type Job = Tables['jobs']['Row'];
export type Proposal = Tables['proposals']['Row'];
export type Milestone = Tables['milestones']['Row'];
export type Message = Tables['messages']['Row'];
export type Payment = Tables['payments']['Row'];
export type ReputationEvent = Tables['reputation_events']['Row'];
export type Notification = Tables['notifications']['Row'];

// Insert types
export type UserInsert = Tables['users']['Insert'];
export type JobInsert = Tables['jobs']['Insert'];
export type ProposalInsert = Tables['proposals']['Insert'];
export type MilestoneInsert = Tables['milestones']['Insert'];
export type MessageInsert = Tables['messages']['Insert'];

// Update types
export type UserUpdate = Tables['users']['Update'];
export type JobUpdate = Tables['jobs']['Update'];
export type ProposalUpdate = Tables['proposals']['Update'];
